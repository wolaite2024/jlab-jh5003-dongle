1. HIDKitSample
console工程，包含RTKHIKit.dll API的调用示例
其中：
SampleCFU.h/SampleCFU.cpp - CFU API调用示例
SampleEQAjustment.h/SampleEQAjustment.cpp - EQ API调用示例
SampleVendorAPI.h/SampleVendorAPI.cpp - RTK Vendor SPP CMD/EVT API调用示例
SampleBTControl.h/SampleBTControl.cpp - Dongle搜索、配对耳机控制API调用示例

2. DemoTool
EQ参数调整demo tool，提供source_code

3. DebugTool
VendorDebugTool.exe - 用于调试用户自定义Dongle和耳机SPP通信的CMD/EVT