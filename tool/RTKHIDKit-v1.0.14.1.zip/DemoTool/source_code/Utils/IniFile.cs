﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Utils
{
    public class IniFile
    {
        [DllImport("kernel32")]
        public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        
        [DllImport("kernel32")]
        public static extern int GetPrivateProfileString(string section, string key, string defaultVal, System.Text.StringBuilder retVal, int size, string filePath);
    }
}
