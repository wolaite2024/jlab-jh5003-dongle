﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace Utils.DLL
{
    public class DeviceMgr
    {
        public DeviceMgr()
        {
        }

        public string[] DetectDevices(HID_DEVICE_CONFIG devConfig)
        {
            //HID_DEVICE_CONFIG devConfig = new HID_DEVICE_CONFIG();
            //devConfig.vid = 0x0BDA;
            //devConfig.pid = 0x8773;
            //devConfig.usagePage = 0xFF07;
            //devConfig.usageTlc = 0x0212;
            ImportDllMethod.RTKHIDSetDeviceConstraint(devConfig);

            int epPathSize = ImportDllMethod.RTKHIDGetDeviceEPPathListSize();
            if (epPathSize <= 0)
            {
                return null;
            }

            IntPtr ptr = Marshal.AllocHGlobal(epPathSize * 2);
            int rst = ImportDllMethod.RTKHIDGetDeviceEPPathList(ptr, epPathSize);
            if (rst != 0)
            {
                Marshal.FreeHGlobal(ptr);
                return null;
            }

            List<string> list = new List<string>();
            int indicator = 0;
            while (indicator < epPathSize)
            {
                string str = Marshal.PtrToStringUni(ptr + indicator);
                list.Add(str);
                indicator += (str.Length + 1) * 2;
            }

            Marshal.FreeHGlobal(ptr);

            return list.ToArray();
        }
        
    }
}
