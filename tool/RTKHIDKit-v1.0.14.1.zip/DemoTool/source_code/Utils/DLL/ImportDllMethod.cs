﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace Utils.DLL
{
    public enum _IC_PARTNUMBER_ : int
    {
        PARTNUMBER_UNKNOWN = -1,

        PARTNUMBER_8762E = 0,
        PARTNUMBER_8762G,
        PARTNUMBER_8763E_MOUSE,

        PARTNUMBER_8763E_PROXY = 0x1000,
        PARTNUMBER_8763EAU = 0x1000,

        PARTNUMBER_8753B_PROXY = 0x1800,
        PARTNUMBER_8753BAU = 0x1800,

        PARTNUMBER_8773C_PROXY = 0x2000,

        PARTNUMBER_NUM,
    };

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct IC_DESC
    {
        public _IC_PARTNUMBER_ partNum;
        public byte isGaming;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct LOCK_STATUS_INFO_NO_LINK
    {
        public byte commandStatus;  // 0: Request are all correct and accepted.
                                    // 1: Request are all correct but not accepted.
                                    // 2: Some parameter in request are not correct.
        public byte payloadLen;
        public byte lockStatus;     // 0: unlock    1: lock
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;
    };

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CONNECT_DEVICE_STATE
    {
        public byte linkID;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;
        public byte connectState;           // 0x00: Disconnected. 0x01: Connected.
        public byte profileConnectState;	// Bitmask. Bit0: SPP, Bit1: A2DP, Bit2: AVRCP
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct PAIRED_DEV_INFO
    {
        public byte linkID;
        public byte remoteAddrType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;
    };

    public enum HID_P_TYPE : int
    {
        Hid_Input = 0,
        Hid_Output,
        Hid_Feature
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HID_REPORRID_INFO
    {
        public byte reportId;
        public ushort usage;
        public ushort reportSize;
        public HID_P_TYPE inOutFeature;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HID_DEVICE_CONFIG
    {
        public ushort vid;
        public ushort pid;
        public ushort usagePage;
        public ushort usageTlc;

        public byte reportNumber;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public HID_REPORRID_INFO[] reports;
    }

    public static class ImportDllMethod
    {
        private const string _dll = "RTKHIDKit.dll";
        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern void RTKHIDSetDeviceConstraint([In]HID_DEVICE_CONFIG devConfig);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKHIDGetDeviceEPPathListSize();

        [DllImport(_dll, CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKHIDGetDeviceEPPathList([In][Out]IntPtr pathList, [In] int characterNum);

        #region BTControl API
        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlInit(IC_DESC desc);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern void RTKBTCtrlDeInit();

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        public static extern int RTKBTCtrlOpenEndPoint([In]string devicePath,
            [In][Out]ref IntPtr hDevice);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCloseEndPoint([In]IntPtr hDevice);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlQueryLockStatusWithoutLink([In]IntPtr hDevice, [In][Out]IntPtr lockInfo);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlQueryPairedDevInfo([In]IntPtr hDevice, [In]byte linkID, [In][Out]IntPtr pairedDevPtr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlQueryConnectionState([In]IntPtr hDevice, [In]byte linkID, [In][Out]IntPtr connectStatePtr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlPairDevice([In]IntPtr hDevice, [In]byte linkID, [In]ulong addr, [In][Out]IntPtr connectStatePtr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCancelPairDevice([In] IntPtr hDevice);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlDisconnectDeviceViaLinkID([In]IntPtr hDevice, [In]byte linkID, [In][Out]IntPtr connectStatePtr);

        // Invalid
        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlFactoryReset([In]IntPtr hDevice, [In][Out]ref byte commandStatus);
        #endregion

        #region BTControl API, only for 8753BAU
        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlGetDongleAddr([In]IntPtr hDevice, [In][Out]ref ulong addr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlWriteRemoteAddr([In]IntPtr hDevice, [In]ulong rmtAddr);
        #endregion

        #region CIS Mode
        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCISModePairDevice([In]IntPtr hDevice, [In]ulong addr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCISModeCancelPairDevice([In]IntPtr hDevice);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCISModeWriteBindingDeviceAddr([In]IntPtr hDevice, [In]ulong remoteDevAddr);

        [DllImport(_dll, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCISModeReadBindingDeviceAddr([In]IntPtr hDevice, [In][Out]ref ulong addr);
        #endregion

        #region RTK Vendor API
        [DllImport("RTKHIDKit.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKOpenEndPoint([In]string devicePath, [In][Out]ref IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKRegisterDeviceDisconnectCallback([In]IntPtr hDevice,
            [In][MarshalAs(UnmanagedType.FunctionPtr)]DeviceDisconnectCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKUnRegisterDeviceDisconnectCallback([In]IntPtr hDevice);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void DeviceDisconnectCallback([In]IntPtr hDevice, int reason);

        #region Vendor CMD/EVT API
        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKRegisterEventCallback([In]IntPtr hDevice,
            [In][Out][MarshalAs(UnmanagedType.FunctionPtr)]RecvEvtCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKUnRegisterEventCallback([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKSendVendorCommand(
            [In]IntPtr hDevice,
            [In]ushort cmdOpcode,
            [In]IntPtr paraCmd,
            [In]ushort cmdParaLen,
            [In]ushort evtOpcode);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void RecvEvtCallback([In]IntPtr hDevice,
            [In] ushort evtOpCode,
            [In][Out]IntPtr evtBuf,
            [In][Out]ushort evtLen);
        #endregion

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKCloseEndPoint([In]IntPtr hDevice);
        
        #endregion
    }
}
