﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqualizerTestTool.Interface
{
    public interface IPageViewModel
    {
        int Init();
    }
}
