﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Utils.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EqualizerTestTool.Dll;

namespace EqualizerTestTool.Model
{
    public class SamplePointModel : ObservableObject
    {
        public double Freq
        {
            get => freq;
            set
            {
                freq = value;
                RaisePropertyChanged("Freq");
            }
        }
        private double freq;

        public double Gain
        {
            get => gain;
            set
            {
                gain = value;
                RaisePropertyChanged("Gain");
            }
        }
        private double gain;

        public double Q
        {
            get => q;
            set
            {
                q = value;
                RaisePropertyChanged("Q");
            }
        }
        private double q;

        public int BiquadType
        {
            get => biquadType;
            set
            {
                biquadType = value;
                RaisePropertyChanged("BiquadType");
            }
        }
        private int biquadType;
    }

    public class EQParamModel : ObservableObject
    {
        public byte StageNum
        {
            get { return stageNum; }
            set
            {
                stageNum = value;
                RaisePropertyChanged("StageNum");
            }
        }
        private byte stageNum;

        public double GlobalGain
        {
            get { return globalGain; }
            set
            {
                globalGain = value;
                RaisePropertyChanged("GlobalGain");
            }
        }
        private double globalGain;

        //public SAMPLE_FREQENCY SampleFreq
        //{
        //    get { return sampleFreq; }
        //    set
        //    {
        //        sampleFreq = value;
        //        RaisePropertyChanged(() => SampleFreq);
        //    }
        //}
        //private SAMPLE_FREQENCY sampleFreq;

        public List<SamplePointModel> SampleCollection
        {
            get { return sampleCollection; }
            set
            {
                sampleCollection = value;
                RaisePropertyChanged("SampleCollection");
            }
        }
        private List<SamplePointModel> sampleCollection;
    }

    public class MainModel : ObservableObject
    {
        public bool IsGamingMode
        {
            get => isGamingMode;
            set
            {
                isGamingMode = value;
                RaisePropertyChanged("IsGamingMode");
            }
        }
        private bool isGamingMode = false;

        public byte EQMode
        {
            get { return eqMode; }
            set 
            { 
                eqMode = value;
                RaisePropertyChanged("EQMode");
            }
        }
        private byte eqMode;

        public uint SampleFreq
        {
            get { return sampleFreq; }
            set
            {
                sampleFreq = value;
                RaisePropertyChanged("SampleFreq");
            }
        }
        private uint sampleFreq;

        public byte StageNum
        {
            get { return stageNum; }
            set
            {
                stageNum = value;
                RaisePropertyChanged("StageNum");
            }
        }
        private byte stageNum;

        public double GlobalGain
        {
            get { return globalGain; }
            set
            {
                globalGain = value;
                RaisePropertyChanged("GlobalGain");
            }
        }
        private double globalGain;

        public byte EQEntryNumber
        {
            get { return eqEntryNumber; }
            set { 
                eqEntryNumber = value;
                RaisePropertyChanged("EQEntryNumber");
            }
        }
        private byte eqEntryNumber;

        public byte CurrentEQIndex
        {
            get { return currentEQIndex; }
            set
            {
                currentEQIndex = value;
                RaisePropertyChanged("CurrentEQIndex");
            }
        }
        private byte currentEQIndex;

        public bool IsIdle
        {
            get { return isIdle; }
            set
            {
                isIdle = value;
                RaisePropertyChanged("IsIdle");
            }
        }
        private bool isIdle = true;

        public List<SamplePointModel> SampleCollection
        {
            get { return sampleCollection; }
            set
            {
                sampleCollection = value;
                RaisePropertyChanged("SampleCollection");
            }
        }
        private List<SamplePointModel> sampleCollection;

        public ObservableCollection<byte> IndexCollection
        {
            get { return indexCollection; }
            set
            {
                indexCollection = value;
                RaisePropertyChanged("IndexCollection");
            }
        }
        private ObservableCollection<byte> indexCollection = new ObservableCollection<byte>()
        {
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        };

        public List<EQParamModel> SamplePointCollection
        {
            get { return samplePointCollection; }
            set
            {
                samplePointCollection = value;
                RaisePropertyChanged("SamplePointCollection");
            }
        }
        private List<EQParamModel> samplePointCollection;

        public MainModel()
        {
            samplePointCollection = new List<EQParamModel>();
            for (int i = 0; i < 10; i++)
            {
                samplePointCollection.Add(new EQParamModel()
                {
                    SampleCollection = new List<SamplePointModel>()
                    {
                        new SamplePointModel() { Freq = 32 },
                        new SamplePointModel() { Freq = 64 },
                        new SamplePointModel() { Freq = 125 },
                        new SamplePointModel() { Freq = 250 },
                        new SamplePointModel() { Freq = 500 },
                        new SamplePointModel() { Freq = 1000 },
                        new SamplePointModel() { Freq = 2000 },
                        new SamplePointModel() { Freq = 4000 },
                        new SamplePointModel() { Freq = 8000 },
                        new SamplePointModel() { Freq = 16000 },
                    }
                });
            }

            SampleCollection = SamplePointCollection[0].SampleCollection;
        }
    }
}
