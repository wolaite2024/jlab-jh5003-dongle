﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EqualizerTestTool.UserControls
{
    /// <summary>
    /// SamplePointUserControl.xaml 的交互逻辑
    /// </summary>
    public partial class SamplePointUserControl : UserControl
    {
        public enum EnumFilterType : int
        {
            PK = 0,
            LSh,
            HSh,
            LPF,
            HPF
        }

        // Freq
        public string Freq
        {
            get { return (string)GetValue(FreqP); }
            set { SetValue(FreqP, value); }
        }
        public static readonly DependencyProperty FreqP = DependencyProperty.Register(
            "Freq", typeof(string), typeof(SamplePointUserControl), 
            new FrameworkPropertyMetadata(new PropertyChangedCallback(OnFreqChanged)));
        private static void OnFreqChanged(DependencyObject sender,
            DependencyPropertyChangedEventArgs e)
        {

        }

        public static readonly RoutedEvent ForegroundGainChangedEvent = EventManager.RegisterRoutedEvent(
            "ForegroundGainChanged", RoutingStrategy.Bubble, typeof(RoutedPropertyChangedEventHandler<double>),
            typeof(SamplePointUserControl));
        public event RoutedPropertyChangedEventHandler<double> ForegroundGainChanged
        {
            add { AddHandler(ForegroundGainChangedEvent, value); }
            remove { RemoveHandler(ForegroundGainChangedEvent, value); }
        }

        // Gain
        public static readonly RoutedEvent GainChangedEvent = EventManager.RegisterRoutedEvent(
            "GainChanged", RoutingStrategy.Bubble, typeof(RoutedPropertyChangedEventHandler<double>),
            typeof(SamplePointUserControl));
        public event RoutedPropertyChangedEventHandler<double> GainChanged
        {
            add { AddHandler(GainChangedEvent, value); }
            remove { RemoveHandler(GainChangedEvent, value); }
        }
        public double Gain
        {
            get { return (double)GetValue(GainP); }
            set { SetValue(GainP, value); }
        }
        public static readonly DependencyProperty GainP = DependencyProperty.Register(
            "Gain", typeof(double), typeof(SamplePointUserControl),
            new FrameworkPropertyMetadata(new PropertyChangedCallback(OnGainChanged)));
        private static void OnGainChanged(DependencyObject sender,
           DependencyPropertyChangedEventArgs e)
        {
            double oldValue = (double)e.OldValue;
            double newValue = (double)e.NewValue;

            RoutedPropertyChangedEventArgs<double> args = new RoutedPropertyChangedEventArgs<double>(oldValue, newValue);
            args.RoutedEvent = GainChangedEvent;

            SamplePointUserControl uc = (SamplePointUserControl)sender;
            uc.RaiseEvent(args);
        }

        // Q
        public static readonly RoutedEvent QChangedEvent = EventManager.RegisterRoutedEvent(
            "QChanged", RoutingStrategy.Bubble, typeof(RoutedPropertyChangedEventHandler<double>),
            typeof(SamplePointUserControl));
        public event RoutedPropertyChangedEventHandler<double> QChanged
        {
            add { AddHandler(QChangedEvent, value); }
            remove { RemoveHandler(QChangedEvent, value); }
        }
        public double Q
        {
            get { return (double)GetValue(QP); }
            set { SetValue(QP, value); }
        }
        public static readonly DependencyProperty QP = DependencyProperty.Register(
            "Q", typeof(double), typeof(SamplePointUserControl),
            new FrameworkPropertyMetadata(new PropertyChangedCallback(OnQChanged)));
        private static void OnQChanged(DependencyObject sender,
           DependencyPropertyChangedEventArgs e)
        {

        }

        public static readonly RoutedEvent FilterTypeChangedEvent = EventManager.RegisterRoutedEvent(
            "FilterTypeChanged", RoutingStrategy.Bubble, typeof(RoutedPropertyChangedEventHandler<int>),
            typeof(SamplePointUserControl));
        public event RoutedPropertyChangedEventHandler<int> FilterTypeChanged
        {
            add { AddHandler(FilterTypeChangedEvent, value); }
            remove { RemoveHandler(FilterTypeChangedEvent, value); }
        }
        // Type
        public int FilterType
        {
            get { return (int)GetValue(FilterTypeP); }
            set { SetValue(FilterTypeP, value); }
        }
        public static readonly DependencyProperty FilterTypeP = DependencyProperty.Register(
            "FilterType", typeof(int), typeof(SamplePointUserControl),
            new FrameworkPropertyMetadata(new PropertyChangedCallback(OnFilterTypeChanged)));
        private static void OnFilterTypeChanged(DependencyObject sender,
           DependencyPropertyChangedEventArgs e)
        {
            int oldValue = (int)e.OldValue;
            int newValue = (int)e.NewValue;

            RoutedPropertyChangedEventArgs<int> args = new RoutedPropertyChangedEventArgs<int>(oldValue, newValue);
            args.RoutedEvent = FilterTypeChangedEvent;

            SamplePointUserControl uc = (SamplePointUserControl)sender;
            uc.RaiseEvent(args);
        }
        
        public SamplePointUserControl()
        {
            InitializeComponent();

            filterTypeComboBox.ItemsSource = new string[]
            {
                "PK", "LSh", "HSh", "LPF", "HPF"
            };
        }
        
        private void UcSamplePoint_MouseUp(object sender, MouseButtonEventArgs e)
        {
            dbSlider.Focus();
        }

        private void GainTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                if (e.Key == Key.Enter)
                {
                    dbSlider.Focus();
                }
            }
        }

        private void GainTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            string gainText = gainTextBox.Text;
            double newGain = 0;
            bool rst = double.TryParse(gainText, out newGain);
            if (!rst)
            {
                return;
            }

            double oldGain = Math.Round(dbSlider.Value, 2);
            if (newGain > 12)
            {
                newGain = 12;
            }
            if (newGain < -12)
            {
                newGain = -12;
            }
            Gain = newGain;

            if (newGain != oldGain)
            {
                RoutedPropertyChangedEventArgs<double> args = new RoutedPropertyChangedEventArgs<double>(newGain, oldGain);
                dbSlider.Value = newGain;
                args.RoutedEvent = ForegroundGainChangedEvent;
                RaiseEvent(args);
            }
        }

        private void DbSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            double newGain = Math.Round(dbSlider.Value, 2);
            double oldGain = Math.Round(oldSliderValue, 2);

            if (newGain != oldGain)
            {
                RoutedPropertyChangedEventArgs<double> args = new RoutedPropertyChangedEventArgs<double>(newGain, dbSlider.Value);
                args.RoutedEvent = ForegroundGainChangedEvent;
                RaiseEvent(args);
            }
        }

        private void DbSlider_MouseEnter(object sender, MouseEventArgs e)
        {
            oldSliderValue = dbSlider.Value;
        }
        
        private double oldSliderValue = 0;     // Add for click slider
    }

    public class SliderValidValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double gain = (double)value;
            if (gain > 12)
            {
                gain = 12;
            }
            if (gain < -12)
            {
                gain = -12;
            }
            return gain;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double gain = (double)value;
            if (gain > 12)
            {
                gain = 12;
            }
            if (gain < -12)
            {
                gain = -12;
            }
            return gain;
        }
    }
}
