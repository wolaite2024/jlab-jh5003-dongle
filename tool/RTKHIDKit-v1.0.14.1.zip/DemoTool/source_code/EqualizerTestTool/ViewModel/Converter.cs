﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace EqualizerTestTool.ViewModel
{
    public class SamplePointUCEnableConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            bool isIdle = (bool)values[0];
            if (!isIdle)
            {
                return false;
            }

#if TEST
#else
            byte stageNum = (byte)values[1];
            byte curIndex = 0;
            if (!byte.TryParse(parameter.ToString(), out curIndex))
            {
                return false;
            }

            if (curIndex >= stageNum)
            {
                return false;
            }
#endif

            return true;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
