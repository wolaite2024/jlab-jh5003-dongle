﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Utils.Common;

using EqualizerTestTool.Model;
using Utils.Command;
using EqualizerTestTool.Interface;
using EqualizerTestTool.Dll;

namespace EqualizerTestTool.ViewModel
{
    public class MainWindowViewModel : ObservableObject
    {
        public RelayCommand<RoutedEventArgs> LoadCommand
        {
            get
            {
                if (loadCommand == null)
                {
                    loadCommand = new RelayCommand<RoutedEventArgs>((e) => LoadWindow(e));
                }
                return loadCommand;
            }
        }
        private RelayCommand<RoutedEventArgs> loadCommand;

        public List<IPageViewModel> PageViewModels
        {
            get
            {
                if (pageViewModels == null)
                {
                    pageViewModels = new List<IPageViewModel>();
                }
                return pageViewModels;
            }
        }

        public IPageViewModel CurrentPageViewModel
        {
            get { return currentPageViewModel; }
            set
            {
                currentPageViewModel = value;
                RaisePropertyChanged("CurrentPageViewModel");
            }
        }

        public void ChangeViewModel(IPageViewModel viewModel)
        {
            if (!PageViewModels.Contains(viewModel))
            {
                PageViewModels.Add(viewModel);
            }

            CurrentPageViewModel = PageViewModels.FirstOrDefault(vm => vm == viewModel);
        }

        public MainWindowViewModel()
        {
            PageViewModels.Add(new ConnectGuidePageViewModel());
            PageViewModels.Add(new EqualizerPageViewModel());
            CurrentPageViewModel = PageViewModels[0];

            //Init();
        }

        private void LoadWindow(RoutedEventArgs e)
        {
            Init();
        }

        private async void Init()
        {
            await Task.Run(() =>
            {
                int rst = PageViewModels[0].Init();
                if (rst == 0)
                {
                    PageViewModels[1].Init();
                    CurrentPageViewModel = PageViewModels[1];
                }
            });
        }

        private IPageViewModel currentPageViewModel;
        private List<IPageViewModel> pageViewModels;

    }
}
