using System;
using System.Windows;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Runtime.InteropServices;
using Utils.Common;
using Utils.Command;

using EqualizerTestTool.Model;
using EqualizerTestTool.Dll;
using EqualizerTestTool.Interface;

namespace EqualizerTestTool.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class EqualizerPageViewModel : ObservableObject, IPageViewModel
    {
        public MainModel EQModel
        {
            get { return eqModel; }
            set
            {
                eqModel = value;
                RaisePropertyChanged("EQModel");
            }
        }
        private MainModel eqModel;

        public RelayCommand GamingModeCheckCommand
        {
            get
            {
                if (gamingModeCheckCommand == null)
                {
                    gamingModeCheckCommand = new RelayCommand(() => DoEnableGamingMode());
                }
                return gamingModeCheckCommand;
            }
            set
            {
                gamingModeCheckCommand = value;
            }
        }
        private RelayCommand gamingModeCheckCommand;

        public RelayCommand<SelectionChangedEventArgs> SelectEQIndexCommand
        {
            get
            {
                if (selectEQIndexCommand == null)
                {
                    selectEQIndexCommand = new RelayCommand<SelectionChangedEventArgs>(e => SwitchEQIndex(e));
                }
                return selectEQIndexCommand;
            }
            set
            {
                selectEQIndexCommand = value;
            }
        }
        private RelayCommand<SelectionChangedEventArgs> selectEQIndexCommand;

        public RelayCommand<string> GainChangedCommand
        {
            get
            {
                if (gainChangedCommand == null)
                {
                    gainChangedCommand = new RelayCommand<string>((p) => DoGainChangedAction(p));
                }
                return gainChangedCommand;
            }
            set { gainChangedCommand = value; }
        }
        private RelayCommand<string> gainChangedCommand;

        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public EqualizerPageViewModel()
        {
            ////if (IsInDesignMode)
            ////{
            ////    // Code runs in Blend --> create design time data.
            ////}
            ////else
            ////{
            ////    // Code runs "for real"
            ////}
            //DispatcherHelper.Initialize();
            EQModel = new MainModel();
        }

        public int Init()
        {
            // Connect to hid device
            EQInit();
            return 0;
        }

        private void DoGainChangedAction(string indexStr)
        {
#if TEST

#else
            if (m_isEQSpecV3)
            {
                ModifyEQParamV3();
            }
            else
            {
                ModifyEQParam();
            }
#endif
        }

        private void SwitchEQIndex(SelectionChangedEventArgs e)
        {
#if TEST
#else
            // Set EQ Index
            ModifyEQIndex();
#endif
        }

        public async void DoEnableGamingMode()
        {
            await Task.Run(() =>
            {
                EQModel.IsIdle = false;
                bool isEnabled = false;
                int rst = ImportDllMethod.RTKEQToggleGamingMode(m_hDevice, ref isEnabled);
                if (rst != 0)
                {
                    EQModel.IsGamingMode = !EQModel.IsGamingMode;
                    MessageBox.Show(string.Format("Switch gaming/normal mode fail, error code: {0:d}", rst));
                    //Messenger.Default.Send(string.Format("Switch gaming/normal mode fail, error code: {0:d}", rst), "ErrorMessage");
                    goto END;
                }

                if (isEnabled != EQModel.IsGamingMode)
                {
                    EQModel.IsGamingMode = !EQModel.IsGamingMode;
                    MessageBox.Show(string.Format("Switch gaming/normal mode fail, wrong mode.", rst));
                    //Messenger.Default.Send(string.Format("Switch gaming/normal mode fail, wrong mode.", rst), "ErrorMessage");
                    goto END;
                }

                EQModel.EQMode = EQModel.IsGamingMode ? (byte)SPK_EQ_MODE.GAMING_MODE : (byte)SPK_EQ_MODE.NORMAL_MODE;

                // EQ of gaming mode and normal mode may be different, need update after switching mode.
                if (UpdateEQ(true) == 0)
                {
                    // Set eq index to use this eq.
                    // Default EQ index of gaming mode and normal mode may be different, need update current EQ index.
                    SyncModifyEQIndex();
                }

            END:
                EQModel.IsIdle = true;
            });

            // Query current index and eq parameter
        }

        private async void ModifyEQIndex()
        {
            await Task.Run(() =>
            {
                // Not good, in order to wait switch gaming mode completed.
                while (true)
                {
                    if (EQModel.IsIdle)
                    {
                        break;
                    }
                }

                SyncModifyEQIndex();
            });
        }

        private void SyncModifyEQIndex()
        {
            // Recovery previous configured EQ Paramters, because SoC cannot save them.

            int rst = 0;

            EQModel.IsIdle = false;
            EQModel.StageNum = EQModel.SamplePointCollection[EQModel.CurrentEQIndex].StageNum;
            EQModel.SampleCollection = EQModel.SamplePointCollection[EQModel.CurrentEQIndex].SampleCollection;

            byte tmpIndex = 0;
            //rst = ImportDllMethod.RTKQueryAudioEQIndex(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, ref tmpIndex);
            rst = m_vendorEQ.QueryAudioEQIndex(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, ref tmpIndex);
            if (rst != 0)
            {
                MessageBox.Show(string.Format("Query EQ index fail, eqmode: {0:d}, error code: {1:d} (for test)", (SPK_EQ_MODE)EQModel.EQMode, rst));
                //Messenger.Default.Send(string.Format("Query EQ index fail, error code: {0:d} (for test)", rst), "ErrorMessage");
                goto END;
            }

            rst = m_vendorEQ.ModifyAudioEQIndex(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex);
            //rst = ImportDllMethod.RTKModifyAudioEQIndex(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex);
            if (rst != 0)
            {
                MessageBox.Show(string.Format("Modify EQ index fail, error code: {0:d}", rst));
                //Messenger.Default.Send(string.Format("Modify EQ index fail, error code: {0:d}", rst), "ErrorMessage");
                goto END;
            }

            //QueryEQParameter();
            //Thread.Sleep(200);
            if (m_isEQSpecV3)
            {
                EQ_PARAM_V3 param = new EQ_PARAM_V3 { };              
                if (rst == 0 && IsNeedRecoveryParam(ref param))
                {
                    EQ_PARAM_V3 param2 = param.DeepCopy();
                    param.eqParaType = 0;
                    param2.eqParaType = 1;
                    int paraLen = Marshal.SizeOf(typeof(EQ_PARAM_V3));
                    IntPtr ptrParam = Marshal.AllocHGlobal(paraLen * 2);
                    try
                    {
                        EQ_PARAM_V3[] eqParams = new EQ_PARAM_V3[2] { param, param2 };
                        for (int i = 0; i < eqParams.Length; i++)
                        {
                            IntPtr offset = ptrParam + (i * paraLen);
                            Marshal.StructureToPtr(eqParams[i], offset, false);
                        }

                        rst = ImportDllMethod.RTKModifyAudioEQParameterV3(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, ptrParam, 2);
                        if (rst != 0)
                        {
                            MessageBox.Show(string.Format("Recover EQ parameter fail, error code: {0:d}", rst));
                            //Messenger.Default.Send(string.Format("Recover EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                        }

                        InitEQParam(EQModel.CurrentEQIndex, param, EQModel.CurrentEQIndex);
                    }
                    finally
                    {
                        Marshal.FreeHGlobal(ptrParam);
                    }
                }
            }
            else
            {
                EQ_PARAM param = new EQ_PARAM { };
                if (rst == 0
                    && IsNeedRecoveryParam(ref param))
                {
                    IntPtr ptr = Marshal.AllocHGlobal(2);
                    if (m_isSupportEQPersistent)
                    {
                        byte[] sampleRates = new byte[2] { (byte)SAMPLE_FREQENCY.FREQ_44P1K, (byte)SAMPLE_FREQENCY.FREQ_48K };
                        Marshal.Copy(sampleRates, 0, ptr, 2);

                        rst = ImportDllMethod.RTKModifyAudioEQParameter(m_hDevice,
                            (SPK_EQ_MODE)EQModel.EQMode,
                            EQModel.CurrentEQIndex,
                            param,
                            ptr,
                            2);
                    }
                    else
                    {
                        byte[] sampleRates = new byte[1] { (byte)param.sampleFreq };
                        Marshal.Copy(sampleRates, 0, ptr, 1);

                        rst = ImportDllMethod.RTKModifyAudioEQParameter(m_hDevice,
                            (SPK_EQ_MODE)EQModel.EQMode,
                            EQModel.CurrentEQIndex,
                            param,
                            ptr,
                            1);
                    }
                    if (rst != 0)
                    {
                        MessageBox.Show(string.Format("Recover EQ parameter fail, error code: {0:d}", rst));
                        //Messenger.Default.Send(string.Format("Recover EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                    }
                    Marshal.FreeHGlobal(ptr);

                    InitEQParam(EQModel.CurrentEQIndex, param, EQModel.CurrentEQIndex);
                }

            }
        END:
            EQModel.IsIdle = true;
        }

        private bool IsNeedRecoveryParam(ref EQ_PARAM eqParam)
        {
            if (m_isSupportEQPersistent)
            {
                return false;
            }

            if (EQModel.IsGamingMode)
            {
                if (m_dictGamingEQParam.ContainsKey(EQModel.CurrentEQIndex))
                {
                    eqParam = m_dictGamingEQParam[EQModel.CurrentEQIndex];
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (m_dictEQParam.ContainsKey(EQModel.CurrentEQIndex))
                {
                    eqParam = m_dictEQParam[EQModel.CurrentEQIndex];
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private bool IsNeedRecoveryParam(ref EQ_PARAM_V3 eqParam)
        {
            if (m_isSupportEQPersistent)
            {
                return false;
            }

            if (EQModel.IsGamingMode)
            {
                if (m_dictGamingEQParamV3.ContainsKey(EQModel.CurrentEQIndex))
                {
                    eqParam = m_dictGamingEQParamV3[EQModel.CurrentEQIndex];
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (m_dictEQParamV3.ContainsKey(EQModel.CurrentEQIndex))
                {
                    eqParam = m_dictEQParamV3[EQModel.CurrentEQIndex];
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        private async void ModifyEQParam()
        {
            await Task.Run(() =>
            {
                EQModel.IsIdle = false;

                QueryEQParameter();

                SAMPLE_FREQENCY sampleFreq = SAMPLE_FREQENCY.FREQ_44P1K;
                if (EQModel.SampleFreq == 48000)
                {
                    sampleFreq = SAMPLE_FREQENCY.FREQ_48K;
                }

                // RTKModifyAudioEQParameter
                IntPtr ptr = Marshal.AllocHGlobal(2);

                EQ_PARAM eqParam = new EQ_PARAM();
                eqParam.sampleFreq = sampleFreq;
                eqParam.stageNum = EQModel.SamplePointCollection[EQModel.CurrentEQIndex].StageNum;
                eqParam.globalGain = EQModel.GlobalGain/*EQModel.SamplePointCollection[EQModel.CurrentEQIndex].GlobalGain*/;

                const int c_Max = 10;
                eqParam.freq = new double[c_Max];
                eqParam.gain = new double[c_Max];
                eqParam.Q = new double[c_Max];
                eqParam.biquadType = new int[c_Max];
                for (int i = 0; i < eqParam.stageNum; i++)
                {
                    eqParam.freq[i] = EQModel.SampleCollection[i].Freq;
                    eqParam.gain[i] = EQModel.SampleCollection[i].Gain;
                    eqParam.Q[i] = EQModel.SampleCollection[i].Q;
                    eqParam.biquadType[i] = EQModel.SampleCollection[i].BiquadType;
                }

                int rst = 0;
                if (m_isSupportEQPersistent)
                {
                    byte[] sampleRates = new byte[2] { (byte)SAMPLE_FREQENCY.FREQ_44P1K, (byte)SAMPLE_FREQENCY.FREQ_48K };
                    Marshal.Copy(sampleRates, 0, ptr, 2);
                    rst = ImportDllMethod.RTKModifyAudioEQParameter(m_hDevice,
                    (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, eqParam, ptr, 2);
                }
                else
                {
                    byte[] sampleRates = new byte[1] { (byte)sampleFreq };
                    Marshal.Copy(sampleRates, 0, ptr, 1);
                    rst = ImportDllMethod.RTKModifyAudioEQParameter(m_hDevice,
                    (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, eqParam, ptr, 1);
                }

                if (rst != 0)
                {
                    MessageBox.Show(string.Format("Modify EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                    //Messenger.Default.Send(string.Format("Modify EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                }
                Marshal.FreeHGlobal(ptr);

                if (rst == 0)
                {
                    // Save EQ Parameter
                    UpdateEQParam(EQModel.CurrentEQIndex, eqParam);
                }

                EQModel.IsIdle = true;
            });
        }

        private async void ModifyEQParamV3()
        {
            await Task.Run(() =>
            {
                EQModel.IsIdle = false;

                QueryEQParameterV3();

                // RTKModifyAudioEQParameter
                EQ_PARAM_V3 eqParam = new EQ_PARAM_V3();
                eqParam.eqParaType = 0; // Final EQ Parameters
                eqParam.stageNum = EQModel.SamplePointCollection[EQModel.CurrentEQIndex].StageNum;
                eqParam.globalGain = EQModel.GlobalGain;

                const int c_Max = 10;
                eqParam.freq = new double[c_Max];
                eqParam.gain = new double[c_Max];
                eqParam.Q = new double[c_Max];
                eqParam.biquadType = new int[c_Max];
                for (int i = 0; i < eqParam.stageNum; i++)
                {
                    eqParam.freq[i] = EQModel.SampleCollection[i].Freq;
                    eqParam.gain[i] = EQModel.SampleCollection[i].Gain;
                    eqParam.Q[i] = EQModel.SampleCollection[i].Q;
                    eqParam.biquadType[i] = EQModel.SampleCollection[i].BiquadType;
                }

                EQ_PARAM_V3 eqParam2 = eqParam.DeepCopy();
                eqParam2.eqParaType = 1; // UI EQ Parameters

                int paraLen = Marshal.SizeOf(typeof(EQ_PARAM_V3));
                IntPtr ptrParam = Marshal.AllocHGlobal(paraLen * 2);
                try
                {
                    EQ_PARAM_V3[] eqParams = new EQ_PARAM_V3[2] { eqParam, eqParam2 };
                    for (int i = 0; i < eqParams.Length; i++)
                    {
                        IntPtr offset = ptrParam + (i * paraLen);
                        Marshal.StructureToPtr(eqParams[i], offset, false);
                    }

                    int rst = ImportDllMethod.RTKModifyAudioEQParameterV3(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, ptrParam, 2);
                    if (rst != 0)
                    {
                        MessageBox.Show(string.Format("Modify EQV3 parameter fail, error code: {0:d}", rst), "ErrorMessage");
                    }
                    else
                    {
                        // Save EQ Parameter
                        UpdateEQParam(EQModel.CurrentEQIndex, eqParam);
                    }

                    EQModel.IsIdle = true;
                }
                finally
                {
                    Marshal.FreeHGlobal(ptrParam);
                }
            });
        }

        private void QueryEQParameter()
        {
            IntPtr ptrParam = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(EQ_PARAM)));
            int rst = ImportDllMethod.RTKQueryAudioEQParameter(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, ptrParam);
            if (rst != 0)
            {
                // TODO: return
                MessageBox.Show(string.Format("Query EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                //Messenger.Default.Send(string.Format("Query EQ ({0:d}) information fail, error code: {0:d}", EQModel.CurrentEQIndex, rst), "ErrorMessage");
            }
            EQ_PARAM param = (EQ_PARAM)Marshal.PtrToStructure(ptrParam, typeof(EQ_PARAM));
            Marshal.FreeHGlobal(ptrParam);

            switch (param.sampleFreq)
            {
                case SAMPLE_FREQENCY.FREQ_44P1K:
                    EQModel.SampleFreq = 44100;
                    break;
                case SAMPLE_FREQENCY.FREQ_48K:
                    EQModel.SampleFreq = 48000;
                    break;
            }
            EQModel.GlobalGain = param.globalGain;

            UpdateEQSampleRate(EQModel.CurrentEQIndex, param);
            // UpdateEQParam(EQModel.CurrentEQIndex, param); //  Can not use this function if SoC can't save eq parameter
        }

        private void QueryEQParameterV3()
        {
            IntPtr ptrParam = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(EQ_PARAM_V3)));
            int eqParamNum = 1;
            int rst = ImportDllMethod.RTKQueryAudioEQParameterV3(m_hDevice, (SPK_EQ_MODE)EQModel.EQMode, EQModel.CurrentEQIndex, ptrParam, ref eqParamNum);
            if (rst != 0)
            {
                // TODO: return
                MessageBox.Show(string.Format("Query EQ parameter fail, error code: {0:d}", rst), "ErrorMessage");
                //Messenger.Default.Send(string.Format("Query EQ ({0:d}) information fail, error code: {0:d}", EQModel.CurrentEQIndex, rst), "ErrorMessage");
            }
            EQ_PARAM_V3 param = (EQ_PARAM_V3)Marshal.PtrToStructure(ptrParam, typeof(EQ_PARAM_V3));
            Marshal.FreeHGlobal(ptrParam);
            EQModel.GlobalGain = param.globalGain;
        }

        // Maybe SoC can't save eq parameter, so only update sample frequency.
        private void UpdateEQSampleRate(byte index, EQ_PARAM param)
        {
            if (m_isSupportEQPersistent)
            {
                return;
            }

            if (EQModel.IsGamingMode)
            {
                if (m_dictGamingEQParam.ContainsKey(index))
                {
                    m_dictGamingEQParam[index].ModifySampleFreq(param.sampleFreq);
                }
                else
                {
                    m_dictGamingEQParam.Add(index, param);
                }
            }
            else
            {
                if (m_dictEQParam.ContainsKey(index))
                {
                    m_dictEQParam[index].ModifySampleFreq(param.sampleFreq);
                }
                else
                {
                    m_dictEQParam.Add(index, param);
                }
            }
        }

        private void UpdateEQParam(byte index, EQ_PARAM param)
        {
            if (m_isSupportEQPersistent)
            {
                return;
            }

            if (EQModel.IsGamingMode)
            {
                if (m_dictGamingEQParam.ContainsKey(index))
                {
                    m_dictGamingEQParam[index] = param;
                }
                else
                {
                    m_dictGamingEQParam.Add(index, param);
                }
            }
            else
            {
                if (m_dictEQParam.ContainsKey(index))
                {
                    m_dictEQParam[index] = param;
                }
                else
                {
                    m_dictEQParam.Add(index, param);
                }
            }
        }

        private void UpdateEQParam(byte index, EQ_PARAM_V3 param)
        {
            if (m_isSupportEQPersistent)
            {
                return;
            }

            if (EQModel.IsGamingMode)
            {
                if (m_dictGamingEQParamV3.ContainsKey(index))
                {
                    m_dictGamingEQParamV3[index] = param;
                }
                else
                {
                    m_dictGamingEQParamV3.Add(index, param);
                }
            }
            else
            {
                if (m_dictEQParamV3.ContainsKey(index))
                {
                    m_dictEQParamV3[index] = param;
                }
                else
                {
                    m_dictEQParamV3.Add(index, param);
                }
            }
        }

        private async void EQInit()
        {
#if TEST
            eqModel.IsIdle = true;
            return;
#endif
            await Task.Run(() =>
            {
                eqModel.IsIdle = false;

                string[] devicePaths = m_remoteDevMgr.DetectDevices();
                if (devicePaths == null
                || devicePaths.Length == 0)
                {
                    MessageBox.Show("Please plug-in dongle!");
                    //Messenger.Default.Send("Please plug-in dongle!", "ErrorMessage");
                    return;
                }
                
                int rst = ImportDllMethod.RTKOpenEndPoint(devicePaths[0], ref m_hDevice);
                if (rst != 0)
                {
                    MessageBox.Show("Connect dongle fail!");
                    //Messenger.Default.Send("Connect dongle fail!", "ErrorMessage");
                    return;
                }

                rst = m_vendorEQ.InitVendorEQClass(m_hDevice);
                if (rst != 0)
                {
                    MessageBox.Show("Vendor API initialize fail!");
                    //Messenger.Default.Send("Vendor API initialize fail!", "ErrorMessage");
                    goto END;
                }

                m_disconnectCallback = new ImportDllMethod.DeviceDisconnectCallback(DongleDisconnectCallback);
                rst = ImportDllMethod.RTKRegisterDeviceDisconnectCallback(m_hDevice, m_disconnectCallback);
                if (rst != 0)
                {
                    MessageBox.Show("Register disconnect callback fail!");
                    //Messenger.Default.Send("Register disconnect callback fail!", "ErrorMessage");
                    goto END;
                }

                m_eqStatusChangedCallback = new ImportDllMethod.EQStatusChangedCallback(EQStatusChangedCallback);
                rst = ImportDllMethod.RTKEQRegisterStatusChangedNotifyCallback(m_hDevice, m_eqStatusChangedCallback);
                if (rst != 0)
                {
                    MessageBox.Show("Register EQ status changed callback fail!");
                    //Messenger.Default.Send("Register EQ status changed callback fail!", "ErrorMessage");
                    return;
                }
               
                rst = ImportDllMethod.RTKEQPrepare(m_hDevice);
                if (rst != 0)
                {
                    MessageBox.Show(string.Format("Prepare fail, error code: {0:d}", rst));
                    //Messenger.Default.Send(string.Format("Prepare fail, error code: {0:d}", rst), "ErrorMessage");
                    return;
                }

                ushort sepcVer = 0;
                rst = ImportDllMethod.RTKQueryEQVersion(ref sepcVer);
                if (rst == 0)
                {
                    m_isEQSpecV3 = (sepcVer == 0x0103);
                }

                m_isSupportEQPersistent = ImportDllMethod.RTKIsSoCSupportEQPersistent(m_hDevice);

                UpdateEQ(false);

                END:
                eqModel.IsIdle = true;
            });
        }

        private int UpdateEQ(bool isSwitchingMode)
        {
            IntPtr ptrInfo = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(EQ_BASIC_INFO)));
            int rst = ImportDllMethod.RTKQueryAudioEQInformation(m_hDevice, ptrInfo);
            if (rst != 0)
            {
                MessageBox.Show(string.Format("Query EQ information fail, error code: {0:d}", rst));
                //Messenger.Default.Send(string.Format("Query EQ information fail, error code: {0:d}", rst), "ErrorMessage");
                return 1;
            }
            EQ_BASIC_INFO info = (EQ_BASIC_INFO)Marshal.PtrToStructure(ptrInfo, typeof(EQ_BASIC_INFO));
            Marshal.FreeHGlobal(ptrInfo);

            // Query all eq parameters
            for (byte i = 0; i < info.eqEntryNumber; i++)
            {
                if (m_isEQSpecV3)
                {
                    IntPtr ptrParam = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(EQ_PARAM_V3)));
                    int eqParamNum = 1; // EQ_PARA_TYPE_UI_EQ
                    rst = ImportDllMethod.RTKQueryAudioEQParameterV3(m_hDevice, info.eqMode, i, ptrParam, ref eqParamNum);
                    if (rst != 0)
                    {
                        // TODO: return
                        MessageBox.Show(string.Format("Query EQV3 ({0:d}) parameter fail, error code: {0:d}", i, rst));
                        //Messenger.Default.Send(string.Format("Query EQ ({0:d}) information fail, error code: {0:d}", i, rst), "ErrorMessage");
                        break;
                    }
                    EQ_PARAM_V3 param = (EQ_PARAM_V3)Marshal.PtrToStructure(ptrParam, typeof(EQ_PARAM_V3));
                    Marshal.FreeHGlobal(ptrParam);

                    InitEQParam(i, param, info.eqIndex);

                    // Only save eq parameters when initialize.
                    if (!isSwitchingMode)
                    {
                        UpdateEQParam(i, param);
                    }
                }
                else
                {
                    IntPtr ptrParam = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(EQ_PARAM)));
                    rst = ImportDllMethod.RTKQueryAudioEQParameter(m_hDevice, info.eqMode, i, ptrParam);
                    if (rst != 0)
                    {
                        // TODO: return
                        MessageBox.Show(string.Format("Query EQ ({0:d}) parameter fail, error code: {0:d}", i, rst));
                        //Messenger.Default.Send(string.Format("Query EQ ({0:d}) information fail, error code: {0:d}", i, rst), "ErrorMessage");
                        break;
                    }
                    EQ_PARAM param = (EQ_PARAM)Marshal.PtrToStructure(ptrParam, typeof(EQ_PARAM));
                    Marshal.FreeHGlobal(ptrParam);

                    InitEQParam(i, param, info.eqIndex);

                    // Only save eq parameters when initialize.
                    if (!isSwitchingMode)
                    {
                        UpdateEQParam(i, param);
                    }
                }
            }

            InitUIByEQ(info);
            return 0;
        }

        private async void UpdateTest()
        {
            await Task.Run(() =>
            {
                // EQ of gaming mode and normal mode may be different, need update after switching mode.
                if (UpdateEQ(true) == 0)
                {
                    // Set eq index to use this eq.
                    // Default EQ index of gaming mode and normal mode may be different, need update current EQ index.
                    SyncModifyEQIndex();
                }
            });
        }

        private void InitEQParam(byte eqIndex, EQ_PARAM eqParam, byte curIndex)
        {
            EQModel.SamplePointCollection[eqIndex].StageNum = eqParam.stageNum;
            switch (eqParam.sampleFreq)
            {
                case SAMPLE_FREQENCY.FREQ_44P1K:
                    EQModel.SampleFreq = 44100;
                    break;
                case SAMPLE_FREQENCY.FREQ_48K:
                    EQModel.SampleFreq = 48000;
                    break;
            }
            //EQModel.SamplePointCollection[eqIndex].SampleFreq = eqParam.sampleFreq;
            if (curIndex == eqIndex)
            {
                // UI only show global gain of current eq index.
                EQModel.GlobalGain = eqParam.globalGain;
            }
            EQModel.SamplePointCollection[eqIndex].GlobalGain = eqParam.globalGain;
            List<SamplePointModel> samplePointModels = EQModel.SamplePointCollection[eqIndex].SampleCollection;
            
            Application.Current?.Dispatcher.Invoke(() => {
                for (byte i = 0; i < eqParam.stageNum; i++)
                {
                    samplePointModels[i].Freq = eqParam.freq[i];
                    samplePointModels[i].Gain = eqParam.gain[i];
                    samplePointModels[i].Q = eqParam.Q[i];
                    samplePointModels[i].BiquadType = eqParam.biquadType[i];
                }

                // If the stage number is between max_stageNum and 10, reset the gain to 0.
                for (int i = eqParam.stageNum; i < 10; i++)
                {
                    samplePointModels[i].Gain = 0;
                }
            });
        }

        private void InitEQParam(byte eqIndex, EQ_PARAM_V3 eqParam, byte curIndex)
        {
            EQModel.SamplePointCollection[eqIndex].StageNum = eqParam.stageNum;
            //EQModel.SamplePointCollection[eqIndex].SampleFreq = eqParam.sampleFreq;
            if (curIndex == eqIndex)
            {
                // UI only show global gain of current eq index.
                EQModel.GlobalGain = eqParam.globalGain;
            }
            EQModel.SamplePointCollection[eqIndex].GlobalGain = eqParam.globalGain;
            List<SamplePointModel> samplePointModels = EQModel.SamplePointCollection[eqIndex].SampleCollection;

            Application.Current?.Dispatcher.Invoke(() => {
                for (byte i = 0; i < eqParam.stageNum; i++)
                {
                    samplePointModels[i].Freq = eqParam.freq[i];
                    samplePointModels[i].Gain = eqParam.gain[i];
                    samplePointModels[i].Q = eqParam.Q[i];
                    samplePointModels[i].BiquadType = eqParam.biquadType[i];
                }

                // If the stage number is between max_stageNum and 10, reset the gain to 0.
                for (int i = eqParam.stageNum; i < 10; i++)
                {
                    samplePointModels[i].Gain = 0;
                }
            });
        }

        private void InitUIByEQ(EQ_BASIC_INFO basicInfo)
        {
            byte curEQIndex = basicInfo.eqIndex;

            EQModel.IsGamingMode = basicInfo.eqMode == SPK_EQ_MODE.GAMING_MODE ? true : false;
            EQModel.EQMode = (byte)basicInfo.eqMode;

            Application.Current?.Dispatcher.Invoke(() =>
            {
                EQModel.IndexCollection.Clear();
                for (byte i = 0; i < basicInfo.eqEntryNumber; i++)
                {
                    EQModel.IndexCollection.Add(i);
                }
            });

            EQModel.StageNum = EQModel.SamplePointCollection[curEQIndex].StageNum;
            EQModel.CurrentEQIndex = curEQIndex;
            EQModel.SampleCollection = EQModel.SamplePointCollection[curEQIndex].SampleCollection;
            EQModel.GlobalGain = EQModel.SamplePointCollection[curEQIndex].GlobalGain;
        }

        private void DongleDisconnectCallback(IntPtr hDevice, int reason)
        {
            MessageBox.Show("Dongle disconnect!");
            //Messenger.Default.Send("Dongle disconnect!", "ErrorMessage");
        }

        private void EQStatusChangedCallback(EQ_STATUS_TYPE changeType, int status)
        {
            // If gaming mode
            if (changeType == EQ_STATUS_TYPE.ACTIVE_INDEX_CHANGED)
            {
                byte oldIndex = EQModel.CurrentEQIndex;
                if (oldIndex != (byte)status)
                {
                    EQModel.CurrentEQIndex = (byte)status;
                }
            }
            else if (changeType == EQ_STATUS_TYPE.GAMING_MODE_ON_OFF_CHANGED)
            {
                byte oldEQMode = EQModel.EQMode;

                EQModel.IsGamingMode = status == 0 ? false : true;
                EQModel.EQMode = EQModel.IsGamingMode ?
                    (byte)SPK_EQ_MODE.GAMING_MODE : (byte)SPK_EQ_MODE.NORMAL_MODE;

                if (oldEQMode != EQModel.EQMode)    // Only EQ mode swiched, update UI
                {
                    // If sync, pending!!!!!!!!!
                    UpdateTest();
  

                }
                else
                {
                   
                }
            }
        }

        private IntPtr m_hDevice = IntPtr.Zero;

        private bool m_isSupportEQPersistent = false;
        private bool m_isEQSpecV3 = false;

        private ImportDllMethod.DeviceDisconnectCallback m_disconnectCallback;
        private ImportDllMethod.EQStatusChangedCallback m_eqStatusChangedCallback;

        private Dictionary<byte, EQ_PARAM> m_dictEQParam = new Dictionary<byte, EQ_PARAM>();
        private Dictionary<byte, EQ_PARAM> m_dictGamingEQParam = new Dictionary<byte, EQ_PARAM>();

        private Dictionary<byte, EQ_PARAM_V3> m_dictEQParamV3 = new Dictionary<byte, EQ_PARAM_V3>();
        private Dictionary<byte, EQ_PARAM_V3> m_dictGamingEQParamV3 = new Dictionary<byte, EQ_PARAM_V3>();

        private VendorEQClass m_vendorEQ = new VendorEQClass();
        private RemoteDevMgr m_remoteDevMgr = new RemoteDevMgr();
    }
}