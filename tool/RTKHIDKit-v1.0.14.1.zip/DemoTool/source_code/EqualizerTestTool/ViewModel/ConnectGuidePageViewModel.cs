﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utils.Common;

using EqualizerTestTool.Model;
using EqualizerTestTool.Dll;
using EqualizerTestTool.Interface;

namespace EqualizerTestTool.ViewModel
{
    public class ConnectGuidePageViewModel : ObservableObject, IPageViewModel
    {
        public int Init()
        {
#if TEST
            return 0;
#endif

            int rst = m_remoteDevMgr.OpenBTControlEndPoint();
            // TODO: log
            if (rst != 0)
            {
                return rst;
            }

            bool isConnected = m_remoteDevMgr.CheckIfDeviceConnected();
            if (!isConnected)
            {
                // Connect
                while (rst != 0)
                {
                    rst = m_remoteDevMgr.ConnectRemoteDevice();
                }
            }

            // Lock
            if (!m_remoteDevMgr.CheckIfDeviceLocked())
            {
                //rst = m_remoteDevMgr.LockRemoteDevice(true);
            }

            if (rst == 0)
            {
                m_remoteDevMgr.CloseBTControlEndPoint();
                return 0;
            }
            else
            {
                // ? start a new thread??
                return rst;
            }
        }

        private RemoteDevMgr m_remoteDevMgr = new RemoteDevMgr();
    }
}
