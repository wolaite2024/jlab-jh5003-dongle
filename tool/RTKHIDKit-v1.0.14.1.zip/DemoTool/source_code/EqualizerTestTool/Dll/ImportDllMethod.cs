﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace EqualizerTestTool.Dll
{
    public enum SPK_EQ_MODE: byte
    {
        NORMAL_MODE = 0,
        GAMING_MODE = 1,
        ANC_MODE = 2,
    }

    public enum SAMPLE_FREQENCY : byte
    {
        FREQ_44P1K = 3, // 44.1K
        FREQ_48K = 4	// 48K
    }
    
    public enum HID_P_TYPE : int
    {
        Hid_Input = 0,
        Hid_Output,
        Hid_Feature
    }

    public enum EQ_STATUS_TYPE : ushort
    {
        GAMING_MODE_ON_OFF_CHANGED,
        ANC_MODE_ON_OFF_CHANGED,
        ACTIVE_INDEX_CHANGED,
    };


    public enum _IC_PARTNUMBER_ : int
    {
        PARTNUMBER_8753BAU = 0x0,
        PARTNUMBER_8763EAU,

        PARTNUMBER_NUM,
    };

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HID_REPORRID_INFO
    {
        public byte reportId;
        public ushort usage;
        public ushort reportSize;
        public HID_P_TYPE inOutFeature;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct HID_DEVICE_CONFIG
    {
        public ushort vid;
        public ushort pid;
        public ushort usagePage;
        public ushort usageTlc;

        public byte reportNumber;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public HID_REPORRID_INFO[] reports;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct EQ_PARAM
    {
        public byte stageNum;
        public double globalGain;
        public SAMPLE_FREQENCY sampleFreq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] freq;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] gain;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] Q;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public int[] biquadType;

        public void ModifySampleFreq(SAMPLE_FREQENCY sampleF)
        {
            sampleFreq = sampleF;
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct EQ_PARAM_V3
    {
        public int eqParaType;
        public byte stageNum;
        public double globalGain;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] freq;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] gain;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public double[] Q;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public int[] biquadType;

        public EQ_PARAM_V3 DeepCopy()
        {
            return new EQ_PARAM_V3
            {
                eqParaType = this.eqParaType,
                stageNum = this.stageNum,
                globalGain = this.globalGain,
                freq = (double[])this.freq.Clone(),
                gain = (double[])this.gain.Clone(),
                Q = (double[])this.Q.Clone(),
                biquadType = (int[])this.biquadType.Clone()
            };
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct EQ_BASIC_INFO
    {
        public SPK_EQ_MODE eqMode;
        public byte eqState;        // 0: disable	1: enable
        public byte eqEntryNumber;
        public byte eqIndex;        // current active eq index
    };

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct IC_DESC
    {
        public _IC_PARTNUMBER_ partNum;
        public byte isGaming;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct DETECT_LOCK_STATUS_RST
    {
        public byte dongleAddrType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] dongleAddr;
        public byte remoteAddrType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;   // If all of remote address bytes are 0, disconnect
        public byte lockStatus;	    // 0: unlock  1: lock
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct CONNECT_DEVICE_STATE
    {
        public byte linkID;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;
        public byte connectState;           // 0x00: Disconnected. 0x01: Connected.
        public byte profileConnectState;    // Bitmask. Bit0: SPP, Bit1: A2DP, Bit2: AVRCP
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct LOCK_UNLOCK_RST
    {
        public byte remoteAddrType; // If all of remote address bytes are 0, disconnect
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] remoteAddr;
        public byte lockCmdType;    // 0x00: unlock 0x01: lock
        public byte lockRst;		// (0x00: success ; 0x01: failed;  0x02: timeout)
    }

    public static class ImportDllMethod
    {
        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void RTKHIDSetDeviceConstraint([In]HID_DEVICE_CONFIG devConfig);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKHIDGetDeviceEPPathListSize();

        [DllImport("RTKHIDKit.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKHIDGetDeviceEPPathList([In][Out]IntPtr pathList, [In] int characterNum);

        #region EQAPI
        [DllImport("RTKHIDKit.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKOpenEndPoint([In]string devicePath, [In][Out]ref IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKRegisterDeviceDisconnectCallback([In]IntPtr hDevice,
            [In][MarshalAs(UnmanagedType.FunctionPtr)]DeviceDisconnectCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKUnRegisterDeviceDisconnectCallback([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKEQPrepare([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool RTKIsSoCSupportEQPersistent([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKEQRegisterStatusChangedNotifyCallback([In]IntPtr hDevice,
            [In][MarshalAs(UnmanagedType.FunctionPtr)]EQStatusChangedCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKEQUnRegisterStatusChangedNotify([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKQueryAudioEQInformation([In]IntPtr hDevice, [In][Out]IntPtr info);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKQueryEQVersion([In][Out]ref ushort specVersion);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKEQToggleGamingMode([In]IntPtr hDevice, [In][Out]ref bool gamingModeEnabled);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKQueryAudioEQIndex([In]IntPtr hDevice,
            [In]SPK_EQ_MODE eqMode,
            [In][Out]ref byte curIndex);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKModifyAudioEQIndex([In]IntPtr hDevice,
            [In]SPK_EQ_MODE eqMode,
            [In]byte eqIndex);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKQueryAudioEQParameter(
            [In]IntPtr hDevice,
            [In]SPK_EQ_MODE eqMode,
            [In]byte eqIndex,
            [In][Out]IntPtr eqParam);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKModifyAudioEQParameter(
            [In]IntPtr hDevice,
            [In]SPK_EQ_MODE eqMode,
            [In]byte eqIndex,
            [In]EQ_PARAM eqParam,
            [In]IntPtr sampleRates,
            [In]int sampleRateNum);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKQueryAudioEQParameterV3(
            [In]IntPtr hDevice,
            [In]SPK_EQ_MODE eqMode,
            [In]byte eqIndex,
            [In][Out]IntPtr eqParam,
            [In][Out]ref int eqParamNum);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKModifyAudioEQParameterV3(
            [In] IntPtr hDevice,
            [In] SPK_EQ_MODE eqMode,
            [In] byte eqIndex,
            [In] IntPtr eqParam,
            [In] int eqParamNum);

        #region Vendor CMD/EVT API
        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKRegisterEventCallback([In]IntPtr hDevice,
            [In][Out][MarshalAs(UnmanagedType.FunctionPtr)]RecvEvtCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKUnRegisterEventCallback([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKSendVendorCommand(
            [In]IntPtr hDevice,
            [In]ushort cmdOpcode,
            [In]IntPtr paraCmd,
            [In]ushort cmdParamLen,
            [In]ushort evtOpcode);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void RecvEvtCallback([In]IntPtr hDevice,
            [In] ushort evtOpCode,
            [In][Out]IntPtr evtBuf,
            [In][Out]ushort evtLen);
        #endregion

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKCloseEndPoint([In]IntPtr hDevice);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void EQStatusChangedCallback(EQ_STATUS_TYPE changeType, int status);
        #endregion


        #region BTControl API
        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void RTKBTCtrlInit(IC_DESC desc);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        public static extern int RTKBTCtrlOpenEndPoint([In]string devicePath,
            [In][Out]ref IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlRegisterDeviceDisconnectCallback([In]IntPtr hDevice,
            [In][MarshalAs(UnmanagedType.FunctionPtr)]DeviceDisconnectCallback callback);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlUnRegisterDeviceDisconnectCallback([In]IntPtr hDevice);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlDetectLockStatus([In][Out]IntPtr lockStatus);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlConnectDevice(
            [In]bool isPairingMode,
            [In]byte linkID,
            [In]ulong addr,
            [In][Out]IntPtr connectState);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlLockWithRemoteDev([In]byte remoteAddrType,
            [In]ulong addr,
            [In]bool isLock,
            [In][Out]IntPtr lockUnlockRst);

        [DllImport("RTKHIDKit.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int RTKBTCtrlCloseEndPoint([In]IntPtr hDevice);
        #endregion

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        public delegate void DeviceDisconnectCallback([In]IntPtr hDevice, int reason);
    }
}
