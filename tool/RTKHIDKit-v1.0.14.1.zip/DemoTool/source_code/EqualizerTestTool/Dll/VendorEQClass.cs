﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Runtime.InteropServices;

namespace EqualizerTestTool.Dll
{
    public class VendorEQClass
    {
        public VendorEQClass()
        {
            m_recvEvtCallback = new ImportDllMethod.RecvEvtCallback(ProcRecvEvt);
            //m_eqIndexAE = new AutoResetEvent(false);
            m_eqIndexNode.manualRE = new ManualResetEvent(false);
            m_eqIndexNode.status = 0;

            m_modifyEQIndexNode.manualRE = new ManualResetEvent(false);
            m_modifyEQIndexNode.status = 0;
        }

        public int InitVendorEQClass(IntPtr hDevice)
        {
            return ImportDllMethod.RTKRegisterEventCallback(hDevice, m_recvEvtCallback);
        }

        //public void Test(IntPtr hDevice)
        //{
        //    // Get battery
        //    byte[] cmdParam = new byte[1];
        //    cmdParam[0] = 2;
        //    // byte array to IntPtr
        //    IntPtr cmdPtr = Marshal.AllocHGlobal(1);
        //    Marshal.Copy(cmdParam, 0, cmdPtr, 1);

        //    // CmdOpCode = 0x0018; param len = 1; EvtOpCode = 0x0019
        //    int rst = ImportDllMethod.RTKSendVendorCommand(hDevice, 0x0018, cmdPtr, 1, 0x0019);// param len = 1;
        //    //TODO:...
        //}

        public int ModifyAudioEQIndex(IntPtr hDevice, SPK_EQ_MODE eqMode, byte curIndex)
        {
            MODIFY_EQ_PARAM cmdParam = new MODIFY_EQ_PARAM();
            cmdParam.eqIndex = curIndex;
            cmdParam.eqMode = (byte)eqMode;

            ushort size = (ushort)Marshal.SizeOf(cmdParam);
            IntPtr cmdPtr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(cmdParam, cmdPtr, true);

            m_modifyEQIndexNode.manualRE.Reset();
            int rst = ImportDllMethod.RTKSendVendorCommand(hDevice,
               (ushort)CMD_OPCODE.CMD_AUDIO_EQ_INDEX_SET,
               cmdPtr,
               size,
               0);

            bool waitRst = m_modifyEQIndexNode.manualRE.WaitOne(5000);
            if (!waitRst)
            {
                rst = 2;   // timeout
            }
            else
            {
                if (m_modifyEQIndexNode.status != 0)
                {
                    rst = 3;
                }
            }

            Marshal.FreeHGlobal(cmdPtr);
            return rst;
        }

        public int QueryAudioEQIndex(IntPtr hDevice, SPK_EQ_MODE eqMode, ref byte curIndex)
        {
            int rst = 0;

            // Send
            byte[] cmdParam = new byte[1];
            cmdParam[0] = (byte)eqMode;
            IntPtr ptr = Marshal.AllocHGlobal(1);
            Marshal.Copy(cmdParam, 0, ptr, 1);

            m_eqIndexNode.manualRE.Reset();
            rst = ImportDllMethod.RTKSendVendorCommand(hDevice,
                (ushort)CMD_OPCODE.CMD_EQ_GET_CUR_INDEX, 
                ptr, 
                1,
                (ushort)EVT_OPCODE.EVT_AUDIO_EQ_GET_CUR_INDEX);
            if (rst != 0)
            {
                Marshal.FreeHGlobal(ptr);
                return 1;
            }
            
            bool waitRst = m_eqIndexNode.manualRE.WaitOne(5000);
            if (!waitRst)
            {
                rst = 2;   // timeout
            }
            else
            {
                if (m_eqIndexNode.status != 0)
                {
                    rst = 3;
                }
                else
                {
                    curIndex = m_curIndex;
                }
            }

            Marshal.FreeHGlobal(ptr);
            return rst;
        }

        // Attention! Only for testing, not good!
        private void ProcRecvEvt(IntPtr hDevice, ushort evtOpCode, IntPtr evtBuf, ushort evtLen)
        {
            byte[] data = new byte[evtLen];
            if (evtBuf == IntPtr.Zero)
            {
                return;
            }
            Marshal.Copy(evtBuf, data, 0, evtLen);

            switch (evtOpCode)
            {
                case (ushort)EVT_OPCODE.EVT_AUDIO_EQ_GET_CUR_INDEX:
                    // index
                    m_curIndex = data[0];
                    // Ack to soc
                    m_eqIndexNode.manualRE.Set();
                    break;
                case 0:
                    ushort cmdOpcode = (ushort)(data[0] + 0x100 * data[1]);
                    if (cmdOpcode == (ushort)CMD_OPCODE.CMD_EQ_GET_CUR_INDEX)
                    {
                        m_eqIndexNode.status = data[2];
                        if (data[2] != 0)
                        {
                            m_eqIndexNode.manualRE.Set();
                        }
                    }
                    else if (cmdOpcode == (ushort)CMD_OPCODE.CMD_AUDIO_EQ_INDEX_SET)
                    {
                        m_modifyEQIndexNode.status = data[2];
                        m_modifyEQIndexNode.manualRE.Set();
                    }
                    break;
            }
        }

        private int SendAck(IntPtr hDevice, EVT_OPCODE evtOpCode)
        {
            ACK_PARAM evtAck = new ACK_PARAM { };
            evtAck.opCode = (ushort)evtOpCode;
            evtAck.status = 0;

            // Struct to IntPtr
            int size = Marshal.SizeOf(evtAck);
            IntPtr cmdPtr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(evtAck, cmdPtr, true);

            int rst = ImportDllMethod.RTKSendVendorCommand(hDevice, C_CMD_ACK, cmdPtr, (ushort)size, 0);
            Marshal.FreeHGlobal(cmdPtr);

            return rst;
        }

        private ImportDllMethod.RecvEvtCallback m_recvEvtCallback = null;

        enum CMD_OPCODE : ushort
        {
            CMD_AUDIO_EQ_INDEX_SET = 0x205,
            CMD_EQ_GET_CUR_INDEX = 0x206,
        }

        enum EVT_OPCODE : ushort
        {
            EVT_AUDIO_EQ_GET_CUR_INDEX = 0x0202,
        }

        public struct CMD_NODE
        {
            public ManualResetEvent manualRE;
            public byte status;
        }

        // Query EQ
        private CMD_NODE m_eqIndexNode = new CMD_NODE();
        //private AutoResetEvent m_eqIndexAE;
        private byte m_curIndex = 0;

        private CMD_NODE m_modifyEQIndexNode = new CMD_NODE();

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct MODIFY_EQ_PARAM
        {
            public byte eqIndex;
            public byte eqMode;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct ACK_PARAM
        {
            public ushort opCode;
            public byte status;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct EQ_INDEX_RSP
        {
            public byte index;
            public byte eqMode;
            /* 0: MUSIC_PLAYING;
            1: CHANGE_EQ_MODE;
            2: SWITCH_EQ_INDEX(MMI)
            3: QUERY_EQ_INDEX
            4: UPDATE_EQ_INDEX
            5: GET_UNSAVED_EQ*/
            public byte scene;
        }

        private const ushort C_CMD_ACK = 0x0;
    }
}
