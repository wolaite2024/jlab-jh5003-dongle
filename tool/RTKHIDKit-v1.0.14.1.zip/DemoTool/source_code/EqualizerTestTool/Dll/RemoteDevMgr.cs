﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace EqualizerTestTool.Dll
{
    public class RemoteDevMgr
    {
        public RemoteDevMgr()
        {

        }

        public int OpenBTControlEndPoint()
        {
            string[] devices = DetectDevices();
            if (devices == null
                || devices.Length == 0)
            {
                return 1;
            }

            IC_DESC icDesc = new IC_DESC();
            icDesc.partNum = _IC_PARTNUMBER_.PARTNUMBER_8763EAU;
            icDesc.isGaming = 1;
            ImportDllMethod.RTKBTCtrlInit(icDesc);

            return ImportDllMethod.RTKBTCtrlOpenEndPoint(devices[0], ref m_hDevice);
        }

        public int CloseBTControlEndPoint()
        {
            return ImportDllMethod.RTKBTCtrlCloseEndPoint(m_hDevice);
        }

        public bool CheckIfDeviceConnected()
        {
            // Step1. Detect lock status
            IntPtr detectPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(DETECT_LOCK_STATUS_RST)));
            //int rst = 

            DETECT_LOCK_STATUS_RST detectRst = (DETECT_LOCK_STATUS_RST)Marshal.PtrToStructure(detectPtr, typeof(DETECT_LOCK_STATUS_RST));

            // Step2. Check if dongle is connected with remote device.
            bool isConnected = CheckIfConnected(detectRst.remoteAddr);
            Marshal.FreeHGlobal(detectPtr);

            m_remoteAddrType = detectRst.remoteAddrType;
            m_remoteAddr = detectRst.remoteAddr;
            m_isLocked = detectRst.lockStatus == 0 ? false : true;

            return isConnected;
        }

        public bool CheckIfDeviceLocked()
        {
            return m_isLocked;
        }

        public int ConnectRemoteDevice()
        {
            IntPtr connectPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(CONNECT_DEVICE_STATE)));
            int rst = ImportDllMethod.RTKBTCtrlConnectDevice(false, 0, 0, connectPtr);
            Marshal.FreeHGlobal(connectPtr);

            return rst;
        }

        public string[] DetectDevices()
        {
            HID_DEVICE_CONFIG devConfig = new HID_DEVICE_CONFIG();
            devConfig.vid = 0x0BDA;
            devConfig.pid = 0x8773; // for test
            devConfig.usagePage = 0xFF07;
            devConfig.usageTlc = 0x0212;
            ImportDllMethod.RTKHIDSetDeviceConstraint(devConfig);

            int epPathSize = ImportDllMethod.RTKHIDGetDeviceEPPathListSize();
            if (epPathSize <= 0)
            {
                return null;
            }

            IntPtr ptr = Marshal.AllocHGlobal(epPathSize * 2);
            int rst = ImportDllMethod.RTKHIDGetDeviceEPPathList(ptr, epPathSize);
            if (rst != 0)
            {
                Marshal.FreeHGlobal(ptr);
                return null;
            }

            List<string> list = new List<string>();
            int indicator = 0;
            while (indicator < epPathSize)
            {
                string str = Marshal.PtrToStringUni(ptr + indicator);
                list.Add(str);
                indicator += (str.Length + 1) * 2;
            }

            Marshal.FreeHGlobal(ptr);

            return list.ToArray();
        }

        private bool CheckIfConnected(byte[] remoteAddr)
        {
            byte[] arr = new byte[8];
            Array.Clear(arr, 0, 8);
            Array.Copy(remoteAddr, arr, 6);
            ulong value = BitConverter.ToUInt64(arr, 0);
            if (value == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        private bool m_isLocked = false;
        private byte m_remoteAddrType = 0;
        private byte[] m_remoteAddr;
        private IntPtr m_hDevice = IntPtr.Zero;
    }
}
