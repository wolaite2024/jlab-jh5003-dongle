#pragma once
#include "stdint.h"
#include "RTKHIDCommon.h"

#ifdef RTKHIDCFU_EXPORTS
#define RTKHIDCFUEXPORT_API __declspec(dllexport)
#else
#define RTKHIDCFUEXPORT_API __declspec(dllimport)
#endif // DEBUG

#define MAX_COMPONENT_NUM 7

enum UPDATE_STATUS : uint32_t
{
	UPDATE_COMPLETE,			// Not-used on new spec...
	UPDATE_OFFER_REJECT,		// Not-used on new spec...

	UPDATE_COMPLETE_ALL_OFFER_REJECT,
	UPDATE_CONTINUE_NOT_ALL_OFFER_REJECT,
	UPDATE_CONTINUE = UPDATE_CONTINUE_NOT_ALL_OFFER_REJECT,

	UPDATE_FAIL_ALL_OFFER_REJECT,

	UPDATE_GET_VERSION_FAIL,
	UPDATE_UNKNOWN_COMPONENT_ID,
	UPDATE_UI_SELECTED_WRONG_PARTNUM,

	UPDATE_ADD_IMAGE_START_ERROR,
	UPDATE_ADD_IMAGE_STOP_ERROR,
	UPDATE_ATTACH_BIN_ERROR,
	UPDATE_ADD_IMAGE_UP_TO_MAX_NUM,

	UPDATE_QUERY_BIN_USED_INVALID_BANK,
	UPDATE_QUERY_BIN_FAIL,
	UPDATE_QUERY_OFFER_DATA_FAIL,
	UPDATE_WRONG_BIN_NUMBER,	// Not-used on new spec...

	UPDATE_OFFER_DATA_ERR,
	UPDATE_OFFER_TIMEOUT,
	UPDATE_OFFER_OTHER_ERR,

	UPDATE_PAYLOAD_UI_STOP,
	UPDATE_PAYLOAD_OTHER_ERR,
	UPDATE_PAYLOAD_SEQ_NUM_ERR,
	UPDATE_PAYLOAD_WRITE_ERR,
	UPDATE_PAYLOAD_DATA_TIMEOUT,
	UPDATE_PAYLOAD_DATA_ERR,

	UPDATE_OTHER = 0x1000,
};

enum TYPE_CFU_USAGE_REPORT : uint8_t
{
	CFU_UPDATE_VERSION_REQ = 0,
	CFU_UPDATE_OFFER_RESP,
	CFU_UPDATE_CONTENT_RESP,
	CFU_UPDATE_OFFER_REQ,
	CFU_UPDATE_CONTENT_REQ,
};

#pragma pack(push, 1)
struct UPDATE_CONFIG
{
	bool forceIgnoreVersion;
	bool forceReset;
	bool forceIgnorePlatformID;
	bool isRemoteDevice;
};

struct UPDATE_CALLBACK_INFO
{
	uint8_t percentage;
	uint32_t status;	// 0: ok
	int16_t imgType;	// -1: Unknown
};

struct COMPONENT_VERSION
{
	uint32_t major;
	uint32_t minor;
	uint32_t revision;
	uint32_t build;
};

union COMPONENT_PROPERTY
{
	uint32_t asUInt32; // ??
	struct
	{
		uint8_t bank : 2;
		uint8_t budRole : 2;	//bud role:0x00 single,0x01 pri, 0x02 sec
		uint8_t vendorSpecific0 : 4;
		uint8_t componentId;
		uint8_t platformId;
		uint8_t vendorSpecific1;
	};
};

union COMPONENT_PROPERTY_EXT
{
	uint32_t asUInt32; // ??
	struct
	{
		uint16_t imageID;
		uint16_t rsv;
	};
};

struct COMPONENT_VERSION_AND_PROPERTY
{
	COMPONENT_VERSION ComponentVersion;
	COMPONENT_PROPERTY ComponentProperty;
};

struct COMPONENT_INFO_HEADER
{
	uint8_t componentCount;
	uint16_t reserved0;
	uint8_t protocolRevision : 4;
	uint8_t reserved1 : 3;
	uint8_t extensionFlag : 1;
};

struct COMPONENT_INFO_REPORT
{
	uint8_t id;
	COMPONENT_INFO_HEADER header;
	COMPONENT_VERSION_AND_PROPERTY componentVersionsAndProperty[MAX_COMPONENT_NUM];
};
#pragma pack(pop)


#ifndef STATIC_LIB
extern "C" RTKHIDCFUEXPORT_API void RTKCFUInit(IN IC_PARTNUMBER partNum);

extern "C" RTKHIDCFUEXPORT_API void RTKCFUDeInit();

extern "C" RTKHIDCFUEXPORT_API void RTKCFUSetDeviceConfig(IN HID_DEVICE_CONFIG config);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUOpenEndPoint(IN LPCWSTR devicePath, IN OUT HANDLE* hDevice);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUCloseEndPoint(IN HANDLE hDevice);

/****************************** CFU Download ******************************/

extern "C" RTKHIDCFUEXPORT_API int RTKCFUGetDeivceDescription(IN HANDLE hDevice,
	IN OUT COMPONENT_INFO_REPORT* componentInfo);

extern "C" RTKHIDCFUEXPORT_API void RTKCFUSetUpdateConfig(IN UPDATE_CONFIG config);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUGetImageVersion(IN LPCWSTR offerBin,
	IN OUT COMPONENT_VERSION* version);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUAddImageStart();

// Max offer-payload number: 20 
extern "C" RTKHIDCFUEXPORT_API int RTKCFUAddImage(IN LPCWSTR offerBin, IN LPCWSTR payloadBin);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUAddImageStop();

extern "C" RTKHIDCFUEXPORT_API typedef void(*UpdateStatusCallback)(IN HANDLE hDevice,
	IN OUT UPDATE_CALLBACK_INFO info);

extern "C" RTKHIDCFUEXPORT_API int RTKCFURegisterUpdateStatusCallback(IN HANDLE hDevice,
	IN UpdateStatusCallback callback);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUUnRegisterUpdateStatusCallback(IN HANDLE hDevice);

// Set delay before sending the next data packet, unit: millisecond, max: 1000ms
extern "C" RTKHIDCFUEXPORT_API int RTKCFUSetTransDelay(IN HANDLE hDevice, int delay);

// Set timeout of sending data packet, unit: millisecond, max: 2000ms
extern "C" RTKHIDCFUEXPORT_API int RTKCFUSetTransTimeout(IN HANDLE hDevice, int timeout);
 
// Time-consumed
extern "C" RTKHIDCFUEXPORT_API UPDATE_STATUS RTKCFUStartUpdate(IN HANDLE hDevice);

extern "C" RTKHIDCFUEXPORT_API int RTKCFUStopUpdate(IN HANDLE hDevice);


#else
extern "C" void RTKCFUInit(IN IC_PARTNUMBER partNum);

extern "C" void RTKCFUDeInit();

extern "C" void RTKCFUSetDeviceConfig(IN HID_DEVICE_CONFIG config);

extern "C" int RTKCFUOpenEndPoint(IN LPCWSTR devicePath, IN OUT HANDLE* hDevice);

extern "C" int RTKCFUCloseEndPoint(IN HANDLE hDevice);

extern "C" int RTKCFUGetDeivceDescription(IN HANDLE hDevice,
	IN OUT COMPONENT_INFO_REPORT* componentInfo);

extern "C" void RTKCFUSetUpdateConfig(IN UPDATE_CONFIG config);

extern "C" int RTKCFUGetImageVersion(IN LPCWSTR offerBin,
	IN OUT COMPONENT_VERSION* version);

extern "C" int RTKCFUAddImageStart();

// Max offer-payload number: 8 (left/right, bank0/bank1)
extern "C" int RTKCFUAddImage(IN LPCWSTR offerBin, IN LPCWSTR payloadBin);

extern "C" int RTKCFUAddImageStop();

extern "C" typedef void(*UpdateStatusCallback)(IN HANDLE hDevice,
	IN OUT UPDATE_CALLBACK_INFO info);

extern "C" int RTKCFURegisterUpdateStatusCallback(IN HANDLE hDevice,
	IN UpdateStatusCallback callback);

extern "C" int RTKCFUUnRegisterUpdateStatusCallback(IN HANDLE hDevice);

// Time-consumed
extern "C" UPDATE_STATUS RTKCFUStartUpdate(IN HANDLE hDevice);

extern "C" int RTKCFUStopUpdate(IN HANDLE hDevice);
#endif