#pragma once
#include "stdint.h"
#include "RTKHIDCommon.h"

#ifdef RTKHIDDETECTEP_EXPORTS
#define RTKHIDDETECTEP_API __declspec(dllexport)
#else
#define RTKHIDDETECTEP_API __declspec(dllimport)
#endif


#ifndef STATIC_LIB
//#ifdef RTKHIDDETECTEP_EXPORTS

extern "C" RTKHIDDETECTEP_API void RTKHIDSetDeviceConstraint(IN HID_DEVICE_CONFIG config);

extern "C" RTKHIDDETECTEP_API int RTKHIDGetDeviceEPPathListSize();

extern "C" RTKHIDDETECTEP_API int RTKHIDGetDeviceEPPathList(IN OUT wchar_t* pathList, IN int characterNum);

#else

extern "C" void RTKHIDSetDeviceConstraint(IN HID_DEVICE_CONFIG config);

extern "C" int RTKHIDGetDeviceEPPathListSize();

extern "C" int RTKHIDGetDeviceEPPathList(IN OUT wchar_t* pathList, IN int characterNum);
#endif

