#pragma once
#include "windows.h"
#include "stdint.h"
#include "RTKHIDCommon.h"

#ifdef RTKHIDBTCONTROL_EXPORTS
#define RTKHIDBTCONTROL_API __declspec(dllexport)
#else
#define RTKHIDBTCONTROL_API __declspec(dllimport)
#endif // DEBU


#pragma pack(push, 1)

struct LOCK_STATUS_INFO_NO_LINK
{
	uint8_t commandStatus;	// 0: Request are all correct and accepted.
							// 1: Request are all correct but not accepted.
							// 2: Some parameter in request are not correct.
	uint8_t payloadLen;
	uint8_t lockStatus;     // 0: unlock    1: lock
	uint8_t remoteAddr[6];
};

struct CONNECT_DEVICE_STATE
{
	uint8_t linkID;
	uint8_t remoteAddr[6];
	uint8_t connectState;			// 0x00: Disconnected. 0x01: Connected.
	uint8_t profileConnectState;	// Bitmask. Bit0: SPP, Bit1: A2DP, Bit2: AVRCP
};

struct PAIRED_DEV_INFO
{
	uint8_t linkID;
	uint8_t remoteAddrType;
	uint8_t remoteAddr[6];
};

struct IC_DESC
{
	IC_PARTNUMBER partNum;
	bool isGaming;
};

#pragma pack(pop)

extern "C" RTKHIDBTCONTROL_API void RTKBTCtrlInit(IN IC_DESC desc);

extern "C" RTKHIDBTCONTROL_API void RTKBTCtrlSetDuplexReport(IN HID_REPORRID_INFO inDirection, IN HID_REPORRID_INFO outDirection);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlOpenEndPoint(IN LPCWSTR devicePath, IN OUT HANDLE* hDevice);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlRegisterDeviceDisconnectCallback(IN HANDLE hDevice, IN DisconnectNotify callback);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlUnRegisterDeviceDisconnectCallback(IN HANDLE hDevice);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlQueryLockStatusWithoutLink(IN HANDLE hDevice, IN OUT LOCK_STATUS_INFO_NO_LINK* evtParam);

// For 8753BAU, query BT address.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlGetDongleAddr(IN HANDLE hDevice, IN OUT ULONGLONG* addr);

// For 8753BAU, write remote headset address.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlWriteRemoteAddr(IN HANDLE hDevice, IN OUT ULONGLONG addr);

// Query connection state
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlQueryConnectionState(IN HANDLE hDevice, IN uint8_t linkID, IN OUT CONNECT_DEVICE_STATE* connectState);

// Query paired device info, linkID is fixed to 0 currently.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlQueryPairedDevInfo(IN HANDLE hDevice, IN uint8_t linkID, IN OUT PAIRED_DEV_INFO* pairedDevInfo);

// Discover and connect device, linkID is fixed to 0.
// Maybe time-consuming.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlPairDevice(IN HANDLE hDevice, 
	IN uint8_t linkID,
	IN ULONGLONG addr,
	IN OUT CONNECT_DEVICE_STATE* connectState);
// Only API cancel.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCancelPairDevice(IN HANDLE hDevice);

// linkID is fixed to 0.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlDisconnectDeviceViaLinkID(IN HANDLE hDevice,
	IN uint8_t linkID,
	IN OUT CONNECT_DEVICE_STATE* connectState);



/******** Send User-Defined CMD and Parameters. ********/
extern "C" RTKHIDBTCONTROL_API typedef void(*BTCtrlRecvEvent)(
	IN HANDLE hDevice,
	IN uint16_t evtOpCode,
	IN OUT uint8_t* evtBuf,
	IN OUT uint16_t evtLen);//allocate max len

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlRegisterEventCallback(IN HANDLE hDevice, IN OUT BTCtrlRecvEvent fn);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlUnRegisterEventCallback(IN HANDLE hDevice);

// cmdLen: The parameter's bytes following cmdOpCode.
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlSendCommand(
	IN HANDLE hDevice,
	IN uint16_t cmdOpcode,
	IN uint8_t* paramCmd,
	IN uint16_t cmdLen,
	IN uint16_t evtOpcode);
/******** Send User-Defined CMD and Parameters. ********/

/******** Send and receive raw data, no data packet ********/
extern "C" RTKHIDBTCONTROL_API typedef void(*BTCtrlRecvDataBuf)(
	IN HANDLE hDevice,
	IN OUT uint8_t* pDataBuf,
	IN OUT uint16_t dataLen);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlRegisterRawDataCallback(IN HANDLE hDevice, IN OUT BTCtrlRecvDataBuf fn);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlUnRegisterRawDataCallback(IN HANDLE hDevice);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlSendRawData(IN HANDLE hDevice, IN uint8_t* pDataBuf, IN uint16_t dataLen);

/******** Send and receive raw data, no data packet ********/

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCloseEndPoint(IN HANDLE hDevice);

extern "C" RTKHIDBTCONTROL_API void RTKBTCtrlDeInit();