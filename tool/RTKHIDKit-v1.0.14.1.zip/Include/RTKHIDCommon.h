#pragma once
#include "windows.h"

typedef void(*DisconnectNotify)(HANDLE hDevice, int reason);

#define MAX_REPORT_NUM 20

enum IC_PARTNUMBER : int
{
	PARTNUMBER_UNKNOWN = -1,

	PARTNUMBER_8762E = 0,
	PARTNUMBER_8762G,
	PARTNUMBER_8763E_MOUSE,

	PARTNUMBER_8763HTV,

	PARTNUMBER_8763E_PROXY = 0x1000,
	PARTNUMBER_8763EAU = 0x1000,

	PARTNUMBER_8753B_PROXY = 0x1800,
	PARTNUMBER_8753BAU = 0x1800,

	PARTNUMBER_8773C_PROXY = 0x2000,

	PARTNUMBER_8773D_PROXY = 0x3000,
	PARTNUMBER_8773DO = PARTNUMBER_8773D_PROXY,

	PARTNUMBER_NUM,
};

enum HID_P_TYPE : int
{
	Hid_Input = 0,
	Hid_Output,
	Hid_Feature
};

#pragma pack(push, 1)
struct HID_REPORRID_INFO
{
	uint8_t ReportID;
	uint16_t Usage;
	uint16_t ReportSize;
	HID_P_TYPE inOutFeature;	// 0: HidP_Input; 1: HidP_Output; 2: HidP_Feature
};

struct HID_DEVICE_CONFIG
{
	uint16_t Vid;
	uint16_t Pid;

	uint16_t UsagePage;
	uint16_t UsageTlc;	// Top level collection usage

	bool IsCheckReport;		// true: inquiry report id/size used Usage (HID_REPORRID_INFO)
							// false: use user-specified report id/size, ignore Usage (HID_REPORRID_INFO).
	uint8_t ReportNumber;
	HID_REPORRID_INFO Reports[MAX_REPORT_NUM];	// Max: 20???
};
#pragma pack(pop)

enum _SEND_CMD_TYPE_
{
	TYPE_SET_FEATURE,
	TYPE_SET_OUTPUT_REPORT,
	TYPE_GET_FEATUR,
};