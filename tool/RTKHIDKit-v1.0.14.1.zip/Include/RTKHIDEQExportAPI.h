#pragma once
#include "stdint.h"
#include "RTKHIDCommon.h"

#ifdef RTKHIDEQ_EXPORTS
#define RTKHIDEQEXPORT_API __declspec(dllexport)
#else
#define RTKHIDEQEXPORT_API __declspec(dllimport)
#endif // DEBU

#define MAX_STAGE_NUM 10

// EQ Related API

enum SPK_EQ_MODE : uint8_t
{
	NORMAL_MODE = 0,
	GAMING_MODE = 1,
	ANC_MODE = 2,
};

enum EQ_STATUS_TYPE : uint16_t
{
	GAMING_MODE_ON_OFF_CHANGED,
	ANC_MODE_ON_OFF_CHANGED,
	ACTIVE_INDEX_CHANGED,
};

enum SAMPLE_FREQENCY : uint8_t
{
	FREQ_44P1K = 3,	// 44.1K
	FREQ_48K = 4	// 48K
};

enum BIQUAD_TYPE : int
{
	BIQUAD_PK = 0,
	BIQUAD_LSh = 1,
	BIQUAD_HSh = 2,
	BIQUAD_LPF = 3,
	BIQUAD_HPF = 4,
};

enum EQ_PARA_TYPE : int
{
	EQ_PARA_TYPE_FINAL_EQ = 0,				// Final EQ Parameters, apply to DSP
	EQ_PARA_TYPE_UI_EQ = 0x01,				// UI EQ Parameters, sync with phone APP
	EQ_PARA_TYPE_COMPENSATION_EQ = 0x02,	// Compensation EQ Parameters
};

#pragma pack(push, 1)
struct EQ_BASIC_INFO
{
	SPK_EQ_MODE eqMode;
	uint8_t eqState;		// 0: disable	1: enable
	uint8_t eqEntryNumber;
	uint8_t eqIndex;		// current active eq index
};

struct EQ_PARAM
{
	uint8_t stageNum;
	double globalGain;
	SAMPLE_FREQENCY sampleFreq;
	double freq[MAX_STAGE_NUM];			// Actual freq number: stageNum
	double gain[MAX_STAGE_NUM];			// Actual gain number: stageNum
	double Q[MAX_STAGE_NUM];
	BIQUAD_TYPE biquadType[MAX_STAGE_NUM];
};

struct EQ_PARAM_V3
{
	EQ_PARA_TYPE eqParaType; // 0: Final EQ paras	1: UI EQ paras	2: Compensation EQ paras
	uint8_t stageNum;
	double globalGain;
	double freq[MAX_STAGE_NUM];			// Actual freq number: stageNum
	double gain[MAX_STAGE_NUM];			// Actual gain number: stageNum
	double Q[MAX_STAGE_NUM];
	BIQUAD_TYPE biquadType[MAX_STAGE_NUM];
};

#pragma pack(pop)

typedef void(*EQStatusChangedNotify)(EQ_STATUS_TYPE changeType, int status);

// What about multi-device(ep)??

//#ifdef RTKHIDEQ_EXPORTS
extern "C" RTKHIDEQEXPORT_API int RTKOpenEndPoint(IN LPCWSTR devicePath, IN OUT HANDLE* hDevice);

extern "C" RTKHIDEQEXPORT_API int RTKRegisterDeviceDisconnectCallback(IN HANDLE hDevice, IN DisconnectNotify callback);

extern "C" RTKHIDEQEXPORT_API int RTKUnRegisterDeviceDisconnectCallback(IN HANDLE hDevice);

extern "C" RTKHIDEQEXPORT_API int RTKEQPrepare(IN HANDLE hDevice);

extern "C" RTKHIDEQEXPORT_API bool RTKIsSoCSupportEQPersistent(IN HANDLE hDevice);

extern "C" RTKHIDEQEXPORT_API int RTKEQRegisterStatusChangedNotifyCallback(IN HANDLE hDevice, IN EQStatusChangedNotify callback);

extern "C" RTKHIDEQEXPORT_API int RTKEQUnRegisterStatusChangedNotify(IN HANDLE hDevice);

extern "C" RTKHIDEQEXPORT_API int RTKQueryAudioEQInformation(IN HANDLE hDevice, IN OUT EQ_BASIC_INFO* pEqInfo);

extern "C" RTKHIDEQEXPORT_API int RTKQueryEQVersion(IN OUT uint16_t& specVersion);
// Name???
extern "C" RTKHIDEQEXPORT_API int RTKEQToggleGamingMode(IN HANDLE hDevice, IN OUT bool* gamingModeEnabled);

extern "C" RTKHIDEQEXPORT_API int RTKQueryAudioEQIndex(IN HANDLE hDevice, IN SPK_EQ_MODE eqMode, IN OUT uint8_t* curIndex);

extern "C" RTKHIDEQEXPORT_API int RTKModifyAudioEQIndex(IN HANDLE hDevice, IN SPK_EQ_MODE eqMode, IN uint8_t eqIndex);

extern "C" RTKHIDEQEXPORT_API int RTKQueryAudioEQParameter(
	IN HANDLE hDevice,
	IN SPK_EQ_MODE eqMode,
	IN uint8_t eqIndex,
	IN OUT EQ_PARAM* pEqParam);

extern "C" RTKHIDEQEXPORT_API int RTKModifyAudioEQParameter(
	IN HANDLE hDevice,
	IN SPK_EQ_MODE eqMode,
	IN uint8_t eqIndex,
	IN EQ_PARAM eqParam,
	IN SAMPLE_FREQENCY* sampleRates,
	IN int sampleRateNum);

extern "C" RTKHIDEQEXPORT_API int RTKQueryAudioEQParameterV3(
	IN HANDLE hDevice,
	IN SPK_EQ_MODE eqMode,
	IN uint8_t eqIndex,
	IN OUT EQ_PARAM_V3* pEqParam,
	IN OUT int& eqParamNum);

extern "C" RTKHIDEQEXPORT_API int RTKModifyAudioEQParameterV3(
	IN HANDLE hDevice,
	IN SPK_EQ_MODE eqMode,
	IN uint8_t eqIndex,
	IN EQ_PARAM_V3* pEqParam,
	IN int eqParamNum);

extern "C" RTKHIDEQEXPORT_API int RTKCloseEndPoint(IN HANDLE hDevice);
//#endif


// Vendor CMD/EVT API
extern "C" RTKHIDEQEXPORT_API typedef void(*RecvEvent)(
	IN HANDLE hDevice,
	IN uint16_t evtOpCode,
	IN OUT uint8_t* evtBuf,
	IN OUT uint16_t evtLen);//allocate max len

extern "C" RTKHIDEQEXPORT_API int RTKRegisterEventCallback(IN HANDLE hDevice, IN RecvEvent fn);

extern "C" RTKHIDEQEXPORT_API int RTKUnRegisterEventCallback(IN HANDLE hDevice);

// General API
extern "C" RTKHIDEQEXPORT_API int RTKSendVendorCommand(
	IN HANDLE hDevice, 
	IN uint16_t cmdOpcode,
	IN uint8_t* paramCmd,
	IN uint16_t cmdParamLen,
	IN uint16_t evtOpcode);