#pragma once
#include "RTKHIDBTControlExportAPI.h"

#ifdef RTKHIDBTCONTROL_EXPORTS
#define RTKHIDBTCONTROL_API __declspec(dllexport)
#else
#define RTKHIDBTCONTROL_API __declspec(dllimport)
#endif // DEBU


#pragma pack(push, 1)

struct DETECT_LOCK_INFO
{
	uint8_t commandStatus;	// 0: Request are all correct and accepted.
							// 1: Request are all correct but not accepted.
							// 2: Some parameter in request are not correct.
	uint8_t payloadLen;
	uint8_t dongleAddrType;
	uint8_t dongleAddr[6];
	uint8_t remoteAddrType;	// If all of remote address bytes are 0, disconnect
	uint8_t remoteAddr[6];
	uint8_t lockStatus;		// 0: unlock  1: locks
	uint8_t connectState;		// 0: disconnnect 1: connect
};

struct LOCK_UNLOCK_RST
{
	uint8_t commandStatus;	// 0: Request are all correct and accepted.
							// 1: Request are all correct but not accepted.
							// 2: Some parameter in request are not correct.
	uint8_t payloadLen;
	uint8_t remoteAddrType;	// If all of remote address bytes are 0, disconnect
	uint8_t remoteAddr[6];
	uint8_t lockCmdType;	// 0x00: unlock 0x01: lock
	uint8_t lockRst;		// (0x00: success ; 0x01: failed;  0x02: timeout)
};
#pragma pack(pop)

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlQueryLockInfo(IN HANDLE hDevice, IN OUT DETECT_LOCK_INFO* evtParam);

// Lock with remote device
extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlLockWithRemoteDev(IN HANDLE hDevice,
	IN uint8_t remoteAddrType,
	IN ULONGLONG remoteAddr,
	IN bool isLock,
	IN OUT LOCK_UNLOCK_RST* lockUnlockRst);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlFactoryReset(IN HANDLE hDevice, IN OUT uint8_t* commandStatus);



/******** CIS Mode. ********/

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCISModePairDevice(IN HANDLE hDevice, IN ULONGLONG remoteDevAddr);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCISModeCancelPairDevice(IN HANDLE hDevice);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCISModeWriteBindingDeviceAddr(IN HANDLE hDevice, IN ULONGLONG remoteDevAddr);

extern "C" RTKHIDBTCONTROL_API int RTKBTCtrlCISModeReadBindingDeviceAddr(IN HANDLE hDevice, IN OUT ULONGLONG* remteDevAddr);

/******** CIS Mode. ********/