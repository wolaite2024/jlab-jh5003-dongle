#include "SampleVendorAPI.h"
#include "../Include/RTKHIDEQExportAPI.h"
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include <vector>
#include <memory>

//
#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

using namespace std;

void Callback(HANDLE hDevice, uint16_t evtOpCode, uint8_t* pBuf, uint16_t evtLen)
{
	// TODO: Copy pBuf
	int a = 0;
}

void CallVendorAPI()
{
	HID_DEVICE_CONFIG config = HID_DEVICE_CONFIG();
	config.Pid = 0x8773;
	config.Vid = 0x0BDA;
	config.UsagePage = 0xFF07;
	config.UsageTlc = 0x0212;
	RTKHIDSetDeviceConstraint(config);

	int epPathSize = RTKHIDGetDeviceEPPathListSize();
	if (epPathSize <= 0)
	{
		_ASSERT(false);
		printf("Find no device.");
		return;
	}

	unique_ptr<WCHAR[]> spDevEndpointPath = make_unique<WCHAR[]>(epPathSize);
	PWCHAR pDevEndpointPath = spDevEndpointPath.get();

	int rst = RTKHIDGetDeviceEPPathList(pDevEndpointPath, epPathSize);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Get device endpoint path fail, rst %d.", rst);
		return;
	}

	vector<wstring> vecPath;
	PWCHAR pTmpPath = pDevEndpointPath;
	while (*pTmpPath != L'\0')
	{
		vecPath.push_back(pTmpPath);
		pTmpPath += (wcslen(pTmpPath));
	}

	// Use the first device.

	LPCWSTR devicePath = vecPath[0].c_str();
	HANDLE hDevice = INVALID_HANDLE_VALUE;
	rst = RTKOpenEndPoint(devicePath, &hDevice);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Open device fail, rst %d.", rst);
		goto END;
	}

#if true
	rst = RTKRegisterEventCallback(hDevice, Callback);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Register event callback fail, rst %d.", rst);
		goto END;
	}

	uint8_t type = 0;
	rst = RTKSendVendorCommand(hDevice, 0x000c, (uint8_t*)&type, 1, 0x0011);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Send vendor command fail, rst %d.", rst);
		goto END;
	}

	/*printf("Please enter any key to exit.");
	int key = getchar();*/
#endif

END:
	rst = RTKCloseEndPoint(hDevice);
	if (rst != 0)
	{
		printf("Close device fail, rst %d.", rst);
		_ASSERT(false);
	}

}

