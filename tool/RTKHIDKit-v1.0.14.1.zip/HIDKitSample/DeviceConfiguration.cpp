#include "DeviceConfiguration.h"

CDeviceConfiguration::CDeviceConfiguration()
{

}

CDeviceConfiguration::~CDeviceConfiguration()
{

}

HID_DEVICE_CONFIG CDeviceConfiguration::RetrieveDongleConfig()
{
	HID_DEVICE_CONFIG hidDevConfig;
	hidDevConfig.Vid = 0xbda;
	hidDevConfig.Pid = 0x8773;
	hidDevConfig.UsagePage = 0xff0B;
	hidDevConfig.UsageTlc = 0x0104;
	hidDevConfig.ReportNumber = 5;

	HID_REPORRID_INFO reportInfo;
	reportInfo.Usage = 0x62;
	//reportInfo.ReportSize = 60;
	reportInfo.inOutFeature = Hid_Feature;	// HidP_Feature
	hidDevConfig.Reports[CFU_UPDATE_VERSION_REQ] = reportInfo;

	reportInfo.Usage = 0x8A;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Input;	// HidP_Input
	hidDevConfig.Reports[CFU_UPDATE_OFFER_RESP] = reportInfo;

	reportInfo.Usage = 0x66;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Input;	// HidP_Input;
	hidDevConfig.Reports[CFU_UPDATE_CONTENT_RESP] = reportInfo;

	reportInfo.Usage = 0x8e;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Output;	// HidP_Output;
	hidDevConfig.Reports[CFU_UPDATE_OFFER_REQ] = reportInfo;

	reportInfo.Usage = 0x61;
	//reportInfo.ReportSize = 60;
	reportInfo.inOutFeature = Hid_Output;	// HidP_Output;
	hidDevConfig.Reports[CFU_UPDATE_CONTENT_REQ] = reportInfo;

	return hidDevConfig;
}

HID_DEVICE_CONFIG CDeviceConfiguration::RetrieveHeadphoneConfig()
{
	HID_DEVICE_CONFIG hidDevConfig;
	hidDevConfig.Vid = 0xbda;
	hidDevConfig.Pid = 0x8773;
	hidDevConfig.UsagePage = 0xff07;
	hidDevConfig.UsageTlc = 0x0212;
	hidDevConfig.ReportNumber = 5;

	HID_REPORRID_INFO reportInfo;
	reportInfo.Usage = 0xD6;
	//reportInfo.ReportSize = 60;
	reportInfo.inOutFeature = Hid_Feature;	// HidP_Feature
	hidDevConfig.Reports[CFU_UPDATE_VERSION_REQ] = reportInfo;

	reportInfo.Usage = 0xE8;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Input;	// HidP_Input
	hidDevConfig.Reports[CFU_UPDATE_OFFER_RESP] = reportInfo;

	reportInfo.Usage = 0xE0;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Input;	// HidP_Input;
	hidDevConfig.Reports[CFU_UPDATE_CONTENT_RESP] = reportInfo;

	reportInfo.Usage = 0xEC;
	//reportInfo.ReportSize = 16;
	reportInfo.inOutFeature = Hid_Output;	// HidP_Output;
	hidDevConfig.Reports[CFU_UPDATE_OFFER_REQ] = reportInfo;

	reportInfo.Usage = 0xd5;
	//reportInfo.ReportSize = 60;
	reportInfo.inOutFeature = Hid_Output;	// HidP_Output;
	hidDevConfig.Reports[CFU_UPDATE_CONTENT_REQ] = reportInfo;

	//reportInfo.Usage = 0;
	////reportInfo.ReportSize = 60;
	//reportInfo.inOutFeature = 0;	// HidP_Output;
	//hidDevConfig.Reports[CFU_UPDATE_CONTENT_REQ] = reportInfo;

	return hidDevConfig;
}