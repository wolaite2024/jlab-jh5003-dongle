#pragma once

void CallLockAPI();