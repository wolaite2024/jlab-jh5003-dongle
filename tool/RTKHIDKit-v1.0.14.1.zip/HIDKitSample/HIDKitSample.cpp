﻿// HIDKitSample.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#include "SampleEQAjustment.h"
#include "SampleCFU.h"
#include "SampleVendorAPI.h"
#include "SampleBTControl.h"
#include "SampleLockAPI.h"
#include "SampleWriteRemoteAddrAPI.h"
//#include "MouseCFU.h"
#include <iostream>

#define SCENARIO 7

int main()
{
	if (SCENARIO == 1)
	{
		CallCFUAPI();
	}
	else if (SCENARIO == 2)
	{
		CallEQAjustmentAPI();
	}
	else if (SCENARIO == 4)
	{
		CallVendorAPI();
	}
	else if (SCENARIO == 5)
	{
		CallBTControlAPI();
	}
	else if (SCENARIO == 6)
	{
		CallLockAPI();
	}
	else if (SCENARIO == 7)
	{
		CallWriteRemoteAddrAPI();
	}

	printf("Please enter any key to exit.");
	int key = getchar();
}
