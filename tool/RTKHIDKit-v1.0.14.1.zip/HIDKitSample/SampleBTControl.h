#pragma once
#include "windows.h"
#include "stdint.h"

void CallBTControlAPI();