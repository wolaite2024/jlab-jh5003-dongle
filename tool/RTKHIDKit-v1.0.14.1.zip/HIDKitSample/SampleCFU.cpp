﻿#include "SampleCFU.h"

#define DONGLE
#include <iostream>
#include "../Include/RTKHIDCFUExportAPI.h"
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include "DeviceConfiguration.h"
#include <memory>
#include <vector>

using namespace std;

#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

void Callback(HANDLE hDevice, UPDATE_CALLBACK_INFO info)
{
	SYSTEMTIME sys;
	GetLocalTime(&sys);
	
	printf("%02d:%02d:%02d.%03d    HANDLE %d: percentage: %d, status: %d. \r",
		sys.wHour, sys.wMinute, sys.wSecond, sys.wMilliseconds,
		hDevice, info.percentage, info.status);
}

void CallCFUAPI()
{
	int testCnt = 0;
	while (testCnt < 1)
	{
		testCnt++;
		printf("\n================================= Test %d =================================\n", testCnt);

		CDeviceConfiguration deviceConfigure = CDeviceConfiguration();
		HID_DEVICE_CONFIG hidDevConfig;

#ifdef DONGLE
		hidDevConfig = deviceConfigure.RetrieveDongleConfig();
#else
		hidDevConfig = deviceConfigure.RetrieveHeadphoneConfig();
#endif

		RTKHIDSetDeviceConstraint(hidDevConfig);
		RTKCFUInit(PARTNUMBER_8763EAU);		// Set your IC part number

		int epPathSize = RTKHIDGetDeviceEPPathListSize();
		if (epPathSize <= 0)
		{
			_ASSERT(false);
			printf("Find no device.");
			return;
		}

		unique_ptr<WCHAR[]> spDevEndpointPath = make_unique<WCHAR[]>(epPathSize);
		PWCHAR pDevEndpointPath = spDevEndpointPath.get();

		int rst = RTKHIDGetDeviceEPPathList(pDevEndpointPath, epPathSize);
		if (rst != 0)
		{
			_ASSERT(false);
			printf("Get device endpoint path fail, rst %d.", rst);
			return;
		}

		vector<wstring> vecPath;
		PWCHAR pTmpPath = pDevEndpointPath;
		while (*pTmpPath != L'\0')
		{
			vecPath.push_back(pTmpPath);
			pTmpPath += (wcslen(pTmpPath));
		}

		// The second parameter:
		// If true, query ReportID and ReportSize by user-specified Usage;
		// If false, use user-specified ReportID and ReportSize.
		hidDevConfig.IsCheckReport = true;
		RTKCFUSetDeviceConfig(hidDevConfig);

		int devNum = vecPath.size();

		UPDATE_CONFIG updateConfig;
		updateConfig.forceIgnoreVersion = false;
		updateConfig.forceReset = true;
		RTKCFUSetUpdateConfig(updateConfig);

		rst = RTKCFUAddImageStart();
		if (rst != 0)
		{
			printf("Start add CFU image fail, rst %d.", rst);
			_ASSERT(false);
			return;
		}

		/*rst = RTKCFUAddImage(L"E:\\DSY Project\\HID dll相关\\Update Via Dongle\\CFU-ear\\CFU_bank0_Primary.offer.bin",
			L"E:\\DSY Project\\HID dll相关\\Update Via Dongle\\CFU-ear\\CFU_bank0_Primary.payload.bin");
		if (rst != 0)
		{
			printf("Add CFU bank0 image fail, rst %d.", rst);
			_ASSERT(false);
			return;
		}

		rst = RTKCFUAddImage(L"E:\\DSY Project\\HID dll相关\\Update Via Dongle\\CFU-ear\\CFU_bank1_Primary.offer.bin",
			L"E:\\DSY Project\\HID dll相关\\Update Via Dongle\\CFU-ear\\CFU_bank1_Primary.payload.bin");
		if (rst != 0)
		{
			printf("Add CFU bank1 image fail, rst %d.", rst);
			_ASSERT(false);
			return;
		}*/

		rst = RTKCFUAddImage(L"E:\\DSY Project\\HID dll\\20231115\\CFU\\CFU_bank0.offer.bin",
			L"E:\\DSY Project\\HID dll\\20231115\\CFU\\CFU_bank0.payload.bin");
		if (rst != 0)
		{
			printf("Add CFU bank0 image fail, rst %d.", rst);
			_ASSERT(false);
		}

		rst = RTKCFUAddImage(L"E:\\DSY Project\\HID dll\\20231115\\CFU\\CFU_bank1.offer.bin",
			L"E:\\DSY Project\\HID dll\\20231115\\CFU\\CFU_bank1.payload.bin");
		if (rst != 0)
		{
			printf("Add CFU bank1 image fail, rst %d.", rst);
			_ASSERT(false);
		}

		rst = RTKCFUAddImageStop();
		if (rst != 0)
		{
			printf("Stop add CFU image fail, rst %d.", rst);
			_ASSERT(false);
			return;
		}

		int componentNum = 0;
		auto spComponentInfo = make_unique<COMPONENT_INFO_REPORT[]>(MAX_COMPONENT_NUM);
		COMPONENT_INFO_REPORT* pComponentInfo = spComponentInfo.get();

		HANDLE hDevice INVALID_HANDLE_VALUE;
		rst = RTKCFUOpenEndPoint(vecPath[0].c_str(), &hDevice);
		if (rst != 0)
		{
			printf("Open device endpoint fail, rst %d.", rst);
			_ASSERT(false);
			goto END;
		}

		rst = RTKCFUGetDeivceDescription(hDevice, pComponentInfo);
		if (rst != 0)
		{
			printf("Get device description fail, rst %d.", rst);
			_ASSERT(false);
			goto END;
		}
		// Print bank, fw version...
		auto prop = pComponentInfo->componentVersionsAndProperty[0].ComponentProperty;
		auto version = pComponentInfo->componentVersionsAndProperty[0].ComponentVersion;
		printf("\n#################### Device Description ####################\n\
   Component ID: %d\n\
   Current Bank: %d\n\
   Bud Role: %d\n\
   FwVersion: %d.%d.%d.%d\n",
			prop.componentId, prop.bank, prop.budRole,
			version.major, version.minor, version.build, version.revision);

		rst = RTKCFURegisterUpdateStatusCallback(hDevice, Callback);
		if (rst != 0)
		{
			printf("Register update status callback fail, rst %d.", rst);
			_ASSERT(false);
			goto END;
		}

		printf("\n######################## Download ########################\n");
		rst = RTKCFUStartUpdate(hDevice);
		if (rst != 0)
		{
			printf("Update fail, rst %d.", rst);
			_ASSERT(false);
		}

	END:

		rst = RTKCFUUnRegisterUpdateStatusCallback(hDevice);
		if (rst != 0)
		{
			printf("Unregister update status callback fail, rst %d.", rst);
			_ASSERT(false);
		}

		rst = RTKCFUCloseEndPoint(hDevice);
		if (rst != 0)
		{
			printf("Close device endpoint fail, rst %d.", rst);
			_ASSERT(false);
		}

		RTKCFUDeInit();

		Sleep(10000);
	}
}