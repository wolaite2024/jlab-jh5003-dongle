#pragma once
#include "../Include/RTKHIDCFUExportAPI.h"

class CDeviceConfiguration
{
public:
	CDeviceConfiguration();
	~CDeviceConfiguration();

	HID_DEVICE_CONFIG RetrieveDongleConfig();
	HID_DEVICE_CONFIG RetrieveHeadphoneConfig();

private:

};
