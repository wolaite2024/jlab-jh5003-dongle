#include "DetectDevice.h"

using namespace std;

CDetectDevice::CDetectDevice()
{
}

CDetectDevice::~CDetectDevice()
{
}

std::vector<wstring> CDetectDevice::DetectDevice(HID_DEVICE_CONFIG config)
{
	vector<wstring> vecPath;
	RTKHIDSetDeviceConstraint(config);

	int epPathSize = RTKHIDGetDeviceEPPathListSize();
	if (epPathSize <= 0)
	{
		_ASSERT(false);
		printf("Find no device.");
		return vecPath;
	}

	unique_ptr<WCHAR[]> spDevEndpointPath = make_unique<WCHAR[]>(epPathSize);
	PWCHAR pDevEndpointPath = spDevEndpointPath.get();

	int rst = RTKHIDGetDeviceEPPathList(pDevEndpointPath, epPathSize);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Get device endpoint path fail, rst %d.", rst);
		return vecPath;
	}

	PWCHAR pTmpPath = pDevEndpointPath;
	while (*pTmpPath != L'\0')
	{
		vecPath.push_back(pTmpPath);
		pTmpPath += (wcslen(pTmpPath));
	}

	return vecPath;
}