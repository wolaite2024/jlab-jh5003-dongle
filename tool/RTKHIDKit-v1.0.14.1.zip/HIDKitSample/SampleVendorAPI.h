#pragma once

void CallVendorAPI();