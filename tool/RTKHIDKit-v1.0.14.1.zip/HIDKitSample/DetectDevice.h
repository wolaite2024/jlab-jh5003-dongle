#pragma once
#include <vector>
#include <string>
#include "../Include/RTKHIDDetectEPExportAPI.h"

//
#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")
class CDetectDevice
{
public:
	CDetectDevice();
	~CDetectDevice();

	std::vector<std::wstring> DetectDevice(HID_DEVICE_CONFIG config);
};

