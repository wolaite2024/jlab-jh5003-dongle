#include "SampleLockAPI.h"
#include "DetectDevice.h"
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include "../Include/RTKHIDBTControlExportAPI.h"
#include "../Include/RTKHIDBTControlExportAPI1.h"

#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

using namespace std;

void DisconnectCallback1(HANDLE hDevice, int reason)
{
	printf("Device disconnect.");
}

void CallLockAPI()
{
	HID_DEVICE_CONFIG config = HID_DEVICE_CONFIG();
	config.Pid = 0xE032;
	config.Vid = 0x2D99;
	config.UsagePage = 0xFF07;
	config.UsageTlc = 0x0212;

	CDetectDevice detectDev;
	vector<wstring> vecDevice = detectDev.DetectDevice(config);
	if (vecDevice.size() == 0)
	{
		return;
	}

	IC_DESC icDesc = IC_DESC{};
	icDesc.isGaming = true;
	icDesc.partNum = PARTNUMBER_8763EAU;
	DETECT_LOCK_INFO lockInfo = { 0 };

	RTKBTCtrlInit(icDesc);

	HANDLE hDevice = INVALID_HANDLE_VALUE;
	int rst = RTKBTCtrlOpenEndPoint(vecDevice[0].c_str(), &hDevice);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Open device fail, rst %d.", rst);
		goto END;
	}

	rst = RTKBTCtrlRegisterDeviceDisconnectCallback(hDevice, DisconnectCallback1);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Register disconnect callback fail, rst %d.", rst);
		goto END;
	}

	rst = RTKBTCtrlQueryLockInfo(hDevice, &lockInfo);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Query lock info fail, rst %d.", rst);
		goto END;
	}

	if (lockInfo.connectState != 0)	// Connected
	{
		ULONGLONG remoteAddr = 0;
		memcpy_s(&remoteAddr, 6, lockInfo.remoteAddr, 6);
		bool isLock = lockInfo.lockStatus == 0 ? true : false;
		LOCK_UNLOCK_RST lockRst = { 0 };
		rst = RTKBTCtrlLockWithRemoteDev(hDevice, lockInfo.remoteAddrType, remoteAddr, isLock, &lockRst);
		if (rst != 0)
		{
			_ASSERT(false);
			printf("lock/unlock info fail, rst %d.", rst);
			goto END;
		}
	}

	uint8_t data = 0x69;
	rst = RTKBTCtrlSendRawData(hDevice, &data, 1);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Send Raw Data fail, rst %d.", rst);
		goto END;
	}

END:
	rst = RTKBTCtrlCloseEndPoint(hDevice);
	if (rst != 0)
	{
		printf("Close device fail, rst %d.", rst);
		_ASSERT(false);
	}

	getchar();
}