#pragma once

void CallWriteRemoteAddrAPI();

