#include "SampleBTControl.h"
#include "DetectDevice.h"
#include <string>
#include <vector>
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include "../Include/RTKHIDBTControlExportAPI.h"

#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

using namespace std;

void BTCtrlCallback(HANDLE hDevice, uint16_t evtOpCode, uint8_t* pBuf, uint16_t evtLen)
{
	// TODO: Copy pBuf
	int a = 0;
	printf("Event opCode: 0x%x, pBuf_0: 0x%x", evtOpCode, pBuf[0]);
}

void DisconnectCallback(HANDLE hDevice, int reason)
{
	printf("Device disconnect.");
}

void CallBTControlAPI()
{
	HID_DEVICE_CONFIG config = HID_DEVICE_CONFIG();
	config.Pid = 0x8773;
	config.Vid = 0x0BDA;
	config.UsagePage = 0xFF07;
	config.UsageTlc = 0x0212;

	CDetectDevice detectDev;
	vector<wstring> vecDevice = detectDev.DetectDevice(config);
	if (vecDevice.size() == 0)
	{
		return;
	}

	IC_DESC icDesc = IC_DESC{};
	icDesc.isGaming = true;
	icDesc.partNum = PARTNUMBER_8763EAU;
	RTKBTCtrlInit(icDesc);

	PAIRED_DEV_INFO pairedInfo = { 0 };
	CONNECT_DEVICE_STATE connectState = { 0 };

	// If the customer specifies the report id, calling the following API, or use the default report id.
	// RTKBTCtrlSetDuplexReport();

	// Use the first device in this sample.
	// One can utilize on demand if several devices are found.
	HANDLE hDevice = INVALID_HANDLE_VALUE;
	int rst = RTKBTCtrlOpenEndPoint(vecDevice[0].c_str(), &hDevice);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Open device fail, rst %d.", rst);
		goto END;
	}

	rst = RTKBTCtrlRegisterDeviceDisconnectCallback(hDevice, DisconnectCallback);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Register disconnect callback fail, rst %d.", rst);
		goto END;
	}

	// Query pair info
	rst = RTKBTCtrlQueryPairedDevInfo(hDevice, 0, &pairedInfo);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Query paired device info fail, rst %d.", rst);
		goto END;
	}

	rst = RTKBTCtrlQueryConnectionState(hDevice, 0, &connectState);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Query connection state fail, rst %d.", rst);
		goto END;
	}

	// Discover and connect device
	// Case1. Set address to 0, connect the first found device.
	// The API will be pending until connect the device.
	// Or you can invoke RTKBTCtrlCancelPairDevice API to end the pending state.
	if (true)
	{
		rst = RTKBTCtrlPairDevice(hDevice, 0, 0, &connectState);
		if (rst != 0)
		{
			_ASSERT(false);
			printf("Pair device fail, rst %d.", rst);
			goto END;
		}
	}
	else
	{
		// Case2. Set valid bt address to search and connect the device.
		// The API will be pending until connect the device.
		// Or you can invoke RTKBTCtrlCancelPairDevice API to end the pending state.
		ULONGLONG addr = 0xd6ff0a1200c2;
		rst = RTKBTCtrlPairDevice(hDevice, 0, addr, &connectState);
		if (rst != 0)
		{
			_ASSERT(false);
			printf("Pair device fail, rst %d.", rst);
			goto END;
		}
	}

#if false	// Case: Vendor bt control cmd/evt
	rst = RTKBTCtrlRegisterEventCallback(hDevice, BTCtrlCallback);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Register event callback fail, rst %d.", rst); 
		goto END;
	}

	if (1)
	{
		// Example: General_BT_Get_Version Command
		rst = RTKBTCtrlSendCommand(hDevice, 0x2001, nullptr, 0, 0x2E01);
		if (rst != 0)
		{
			_ASSERT(false);
			printf("Send command fail, rst %d.", rst);
			goto END;
		}
	}
	else
	{

	}
#endif

END:
	int key = getchar();
	rst = RTKBTCtrlCloseEndPoint(hDevice);
	if (rst != 0)
	{
		printf("Close device fail, rst %d.", rst);
		_ASSERT(false);
	}
}