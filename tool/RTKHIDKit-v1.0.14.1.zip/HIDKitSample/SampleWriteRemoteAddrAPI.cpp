#include "SampleWriteRemoteAddrAPI.h"
#include "DetectDevice.h"
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include "../Include/RTKHIDBTControlExportAPI.h"
#include "../Include/RTKHIDBTControlExportAPI1.h"

#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

using namespace std;

void CallWriteRemoteAddrAPI()
{
	HID_DEVICE_CONFIG config = HID_DEVICE_CONFIG();
	config.Pid = 0x875B;		// Please check and set your PID
	config.Vid = 0x0BDA;		// Please check and set your VID
	config.UsagePage = 0xFF00;	// Please check and set your UsagePage
	config.UsageTlc = 0x0212;	// Please check and set your UsageTlc

	CDetectDevice detectDev;
	vector<wstring> vecDevice = detectDev.DetectDevice(config);
	if (vecDevice.size() == 0)
	{
		return;
	}

	LOCK_STATUS_INFO_NO_LINK lockInfo = { 0 };

	RTKBTCtrlInit({ PARTNUMBER_8753BAU, false });

	HANDLE hDevice = INVALID_HANDLE_VALUE;
	int rst = RTKBTCtrlOpenEndPoint(vecDevice[0].c_str(), &hDevice);
	if (rst)
	{
		_ASSERT(false);
		printf("Open device fail, rst %d.", rst);
		goto END;
	}

	// Read remote BD addr to check if the dongle has locked with a remote device...
	rst = RTKBTCtrlQueryLockStatusWithoutLink(hDevice, &lockInfo);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Query lock info fail, rst %d.", rst);
		goto END;
	}

	// Check lockInfo.remoteAddr here...
	// TODO

	// Write remote address
	unsigned long long address = 0x112233445566; 
	rst = RTKBTCtrlWriteRemoteAddr(hDevice, address);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Write remote address fail, rst %d.", rst);
		goto END;
	}

	lockInfo = { 0 };
	rst = RTKBTCtrlQueryLockStatusWithoutLink(hDevice, &lockInfo);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Query lock info fail, rst %d.", rst);
		goto END;
	}

	// Check lockInfo.remoteAddr here...
	// TODO

END:
	rst = RTKBTCtrlCloseEndPoint(hDevice);
	if (rst != 0)
	{
		printf("Close device fail, rst %d.", rst);
		_ASSERT(false);
	}
}