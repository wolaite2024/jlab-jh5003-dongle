#pragma once

void CallEQAjustmentAPI();