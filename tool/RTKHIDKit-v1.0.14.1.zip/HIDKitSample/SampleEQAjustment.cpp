#include <iostream>
#include "../Include/RTKHIDEQExportAPI.h"
#include "../Include/RTKHIDDetectEPExportAPI.h"
#include <vector>
#include <memory>

//
#pragma comment(lib, "..\\Release\\RTKHIDKit.lib")

using namespace std;

void FuncEQStatusChanged(EQ_STATUS_TYPE type, int status)
{
	int a = 0;
}

void CallEQAjustmentAPI()
{
	HID_DEVICE_CONFIG config = HID_DEVICE_CONFIG();
	config.Pid = 0x8773;
	config.Vid = 0x0BDA;
	config.UsagePage = 0xFF07;
	config.UsageTlc = 0x0212;
	RTKHIDSetDeviceConstraint(config);

	int epPathSize = RTKHIDGetDeviceEPPathListSize();
	if (epPathSize <= 0)
	{
		_ASSERT(false);
		printf("Find no device.");
		return;
	}

	unique_ptr<WCHAR[]> spDevEndpointPath = make_unique<WCHAR[]>(epPathSize);
	PWCHAR pDevEndpointPath = spDevEndpointPath.get();

	int rst = RTKHIDGetDeviceEPPathList(pDevEndpointPath, epPathSize);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Get device endpoint path fail, rst %d.", rst);
		return;
	}

	vector<wstring> vecPath;
	PWCHAR pTmpPath = pDevEndpointPath;
	while (*pTmpPath != L'\0')
	{
		vecPath.push_back(pTmpPath);
		pTmpPath += (wcslen(pTmpPath));
	}

	// Use the first device.

	LPCWSTR devicePath = vecPath[0].c_str();
	HANDLE hDevice = INVALID_HANDLE_VALUE;
	rst = RTKOpenEndPoint(devicePath, &hDevice);
	if (rst != 0)
	{
		_ASSERT(false);
		printf("Open device fail, rst %d.", rst);
		goto END;
	}

	rst = RTKEQPrepare(hDevice);
	if (rst != 0)
	{
		printf("Prepare EQ fail, rst %d.", rst);
		_ASSERT(false);
		goto END;
	}

	EQ_BASIC_INFO eqInfo = EQ_BASIC_INFO();
	rst = RTKQueryAudioEQInformation(hDevice, &eqInfo);
	if (rst != 0)
	{
		printf("Query audio EQ information fail, rst %d.", rst);
		_ASSERT(false);
	}

END:
	rst = RTKCloseEndPoint(hDevice);
	if (rst != 0)
	{
		printf("Close device fail, rst %d.", rst);
		_ASSERT(false);
	}


	/*uint64_t addr = 0x99aa48185919;
	int rst = DebugEQConnectDevice(addr);
	_ASSERT(rst == 0);

	rst = DebugRegisterEQStatusChangedNotifyCallback(FuncEQStatusChanged);
	_ASSERT(rst == 0);

	rst = DebugEQInit();
	_ASSERT(rst == 0);

	EQ_BASIC_INFO eqInfo = EQ_BASIC_INFO();
	rst = DebugQueryEQInformation(&eqInfo);
	_ASSERT(rst == 0);

	rst = DebugModifyAudioEQIndex(eqInfo.eqMode, 2);
	_ASSERT(rst == 0);

	EQ_PARAM eqParam = { 0 };
	rst = DebugQueryAudioEQParameter(NORMAL_MODE, eqInfo.eqIndex, &eqParam);
	_ASSERT(rst == 0);

	SAMPLE_FREQENCY_FLG sampleRates[1] = { eqParam.sampleFreq };
	rst = DebugModifyAudioEQParameter(eqInfo.eqMode, eqInfo.eqIndex, eqParam, sampleRates, 1);
	_ASSERT(rst == 0);

	//uint8_t gamingModeStatus = 0;
	//rst = DebugSwitchEQMode(gamingModeStatus);
	//_ASSERT(rst == 0);

	rst = DebugUnRegisterEQStatusChangedNotify();
	_ASSERT(rst == 0);

	rst = DebugEQDisconnectDevice(addr);
	_ASSERT(rst == 0);*/
}